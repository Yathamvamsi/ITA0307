import React, { useEffect, useRef } from 'react';
import { Activity, TrendingUp } from 'lucide-react';

export default function TelemetryCharts({
  telemetryHistory, // Array of { time, buffer, bitrate, throughput, level }
  currentBuffer,
  currentBitrate,
  currentThroughput
}) {
  const bufferCanvasRef = useRef(null);
  const bitrateCanvasRef = useRef(null);

  // Render Real-Time Buffer Fill Chart on Canvas
  useEffect(() => {
    const canvas = bufferCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Clear
    ctx.clearRect(0, 0, width, height);

    // Draw Background Grid
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let y = 0; y < height; y += height / 4) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    // Safety Thresholds (Max buffer scale: 20 seconds)
    const maxScaleSec = 20.0;
    const reservoirY = height - (4.0 / maxScaleSec) * height; // 4s line
    const cushionY = height - (10.0 / maxScaleSec) * height; // 10s line

    // Draw Emergency Line (4s)
    ctx.strokeStyle = 'rgba(255, 77, 109, 0.4)';
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(0, reservoirY);
    ctx.lineTo(width, reservoirY);
    ctx.stroke();

    // Draw Cushion Line (10s)
    ctx.strokeStyle = 'rgba(255, 183, 3, 0.35)';
    ctx.beginPath();
    ctx.moveTo(0, cushionY);
    ctx.lineTo(width, cushionY);
    ctx.stroke();
    ctx.setLineDash([]); // Reset line dash

    if (!telemetryHistory || telemetryHistory.length < 2) return;

    // Plot Buffer Curve
    const count = telemetryHistory.length;
    const stepX = width / Math.max(1, count - 1);

    ctx.beginPath();
    ctx.moveTo(0, height - (Math.min(maxScaleSec, telemetryHistory[0].buffer) / maxScaleSec) * height);

    for (let i = 1; i < count; i++) {
      const pt = telemetryHistory[i];
      const x = i * stepX;
      const y = height - (Math.min(maxScaleSec, pt.buffer) / maxScaleSec) * height;
      ctx.lineTo(x, y);
    }

    // Gradient fill under buffer curve
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, 'rgba(0, 230, 153, 0.35)');
    grad.addColorStop(1, 'rgba(0, 230, 153, 0.02)');
    ctx.fillStyle = grad;
    ctx.lineTo((count - 1) * stepX, height);
    ctx.lineTo(0, height);
    ctx.closePath();
    ctx.fill();

    // Line stroke
    ctx.beginPath();
    ctx.moveTo(0, height - (Math.min(maxScaleSec, telemetryHistory[0].buffer) / maxScaleSec) * height);
    for (let i = 1; i < count; i++) {
      const pt = telemetryHistory[i];
      const x = i * stepX;
      const y = height - (Math.min(maxScaleSec, pt.buffer) / maxScaleSec) * height;
      ctx.lineTo(x, y);
    }
    ctx.strokeStyle = '#00e699';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = 'rgba(0, 230, 153, 0.5)';
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0; // Reset
  }, [telemetryHistory]);

  // Render Bitrate vs Channel Throughput Chart on Canvas
  useEffect(() => {
    const canvas = bitrateCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    ctx.clearRect(0, 0, width, height);

    // Max scale: 6 Mbps (6000 kbps)
    const maxScaleKbps = 6000;

    // Grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let y = 0; y < height; y += height / 4) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    if (!telemetryHistory || telemetryHistory.length < 2) return;

    const count = telemetryHistory.length;
    const stepX = width / Math.max(1, count - 1);

    // 1. Throughput curve (dashed cyan line)
    ctx.strokeStyle = 'rgba(0, 242, 254, 0.5)';
    ctx.setLineDash([3, 3]);
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, height - (Math.min(maxScaleKbps, telemetryHistory[0].throughput / 1000) / maxScaleKbps) * height);
    for (let i = 1; i < count; i++) {
      const x = i * stepX;
      const y = height - (Math.min(maxScaleKbps, telemetryHistory[i].throughput / 1000) / maxScaleKbps) * height;
      ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.setLineDash([]);

    // 2. Video Bitrate ladder curve (solid purple/violet line with stepped interpolation)
    ctx.beginPath();
    let prevX = 0;
    let prevY = height - (Math.min(maxScaleKbps, telemetryHistory[0].bitrate / 1000) / maxScaleKbps) * height;
    ctx.moveTo(prevX, prevY);

    for (let i = 1; i < count; i++) {
      const nextX = i * stepX;
      const nextY = height - (Math.min(maxScaleKbps, telemetryHistory[i].bitrate / 1000) / maxScaleKbps) * height;
      // Step horizontal then vertical
      ctx.lineTo(nextX, prevY);
      ctx.lineTo(nextX, nextY);
      prevX = nextX;
      prevY = nextY;
    }

    ctx.strokeStyle = '#a855f7';
    ctx.lineWidth = 2.5;
    ctx.shadowColor = 'rgba(168, 85, 247, 0.6)';
    ctx.shadowBlur = 8;
    ctx.stroke();
    ctx.shadowBlur = 0;
  }, [telemetryHistory]);

  return (
    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))', gap: '1rem' }}>
      {/* Buffer Health Real-time Graph */}
      <div className="glass-panel" style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem', fontWeight: 700 }}>
            <Activity size={16} color="var(--accent-emerald)" />
            <span>Buffer Occupancy vs Safety Thresholds</span>
          </div>
          <span className="mono" style={{ fontSize: '0.8rem', color: 'var(--accent-emerald)', fontWeight: 700 }}>
            {currentBuffer.toFixed(1)}s (Safe)
          </span>
        </div>

        <div style={{ position: 'relative', width: '100%', height: '140px', background: 'rgba(5, 8, 16, 0.6)', borderRadius: '10px', overflow: 'hidden' }}>
          <canvas
            ref={bufferCanvasRef}
            width={480}
            height={140}
            style={{ width: '100%', height: '100%', display: 'block' }}
          />
          {/* Threshold Label Badges */}
          <div style={{ position: 'absolute', top: '8px', left: '8px', display: 'flex', gap: '6px' }}>
            <span style={{ fontSize: '0.65rem', color: '#6ee7b7' }}>Safe Zone (&gt;10s)</span>
            <span style={{ fontSize: '0.65rem', color: '#fde047' }}>Cushion (4-10s)</span>
            <span style={{ fontSize: '0.65rem', color: '#f87171' }}>Reservoir (&lt;4s)</span>
          </div>
        </div>
      </div>

      {/* Bitrate Ladder vs Channel Throughput Graph */}
      <div className="glass-panel" style={{ padding: '1rem', display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', fontSize: '0.85rem', fontWeight: 700 }}>
            <TrendingUp size={16} color="var(--accent-violet)" />
            <span>Active Bitrate vs Channel Throughput</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <span className="mono" style={{ fontSize: '0.72rem', color: '#38bdf8' }}>
              TP: {(currentThroughput / 1000000).toFixed(1)} Mbps
            </span>
            <span className="mono" style={{ fontSize: '0.8rem', color: 'var(--accent-violet)', fontWeight: 700 }}>
              {(currentBitrate / 1000).toFixed(0)} kbps
            </span>
          </div>
        </div>

        <div style={{ position: 'relative', width: '100%', height: '140px', background: 'rgba(5, 8, 16, 0.6)', borderRadius: '10px', overflow: 'hidden' }}>
          <canvas
            ref={bitrateCanvasRef}
            width={480}
            height={140}
            style={{ width: '100%', height: '100%', display: 'block' }}
          />
          {/* Legend */}
          <div style={{ position: 'absolute', top: '8px', left: '8px', display: 'flex', gap: '10px' }}>
            <span style={{ fontSize: '0.65rem', color: '#c084fc', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ width: '8px', height: '3px', background: '#a855f7', display: 'inline-block' }} /> Bitrate Ladder
            </span>
            <span style={{ fontSize: '0.65rem', color: '#38bdf8', display: 'flex', alignItems: 'center', gap: '4px' }}>
              <span style={{ width: '8px', height: '2px', background: '#00f2fe', borderTop: '1px dashed #00f2fe', display: 'inline-block' }} /> Radio Throughput
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
