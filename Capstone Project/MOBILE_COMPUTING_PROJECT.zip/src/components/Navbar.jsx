import React from 'react';
import { 
  Play, 
  Smartphone, 
  Monitor, 
  Wifi, 
  Battery, 
  BatteryCharging, 
  BookOpen, 
  GitCompare, 
  Cpu,
  Activity
} from 'lucide-react';

export default function Navbar({
  viewMode,
  setViewMode,
  selectedAlgorithm,
  setSelectedAlgorithm,
  batteryLevel,
  isCharging,
  networkType,
  onOpenExplainer,
  onOpenBenchmark,
  onOpenNetworkMonitor,
  currentBandwidthKbps,
  currentLatencyMs
}) {
  return (
    <header className="navbar-header" style={{
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '1.25rem 0',
      marginBottom: '1.5rem',
      borderBottom: '1px solid var(--border-subtle)',
      flexWrap: 'wrap',
      gap: '1rem'
    }}>
      {/* Brand & Project Title */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.85rem' }}>
        <div style={{
          width: '42px',
          height: '42px',
          borderRadius: '12px',
          background: 'var(--grad-cyan-blue)',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: 'var(--shadow-glow)'
        }}>
          <Play size={22} color="#070a13" fill="#070a13" style={{ marginLeft: '2px' }} />
        </div>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <h1 style={{ fontSize: '1.4rem', fontWeight: 800, margin: 0 }}>
              Media<span className="gradient-text">Flow</span>
            </h1>
            <span className="badge badge-cyan">CAPSTONE 2026</span>
          </div>
          <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: 0, letterSpacing: '0.02em' }}>
            Adaptive Mobile Multimedia Streaming & Performance Optimization
          </p>
        </div>
      </div>

      {/* Center Controls: Algorithm Switcher */}
      <div className="glass-panel" style={{
        display: 'flex',
        alignItems: 'center',
        padding: '0.3rem',
        borderRadius: '12px',
        gap: '0.35rem'
      }}>
        <div style={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: '0.35rem', 
          padding: '0 0.5rem',
          fontSize: '0.78rem',
          color: '#94a3b8',
          fontWeight: 600
        }}>
          <Cpu size={15} color="var(--accent-cyan)" />
          <span>ALGORITHM:</span>
        </div>

        <button
          className={`btn btn-sm ${selectedAlgorithm === 'MEDIAFLOW_HYBRID' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setSelectedAlgorithm('MEDIAFLOW_HYBRID')}
          title="Mobile-Aware Hybrid Engine (Throughput + BBA + Battery + Thermal)"
        >
          MediaFlow Hybrid
        </button>

        <button
          className={`btn btn-sm ${selectedAlgorithm === 'BBA' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setSelectedAlgorithm('BBA')}
          title="Buffer-Based Adaptation (Huang et al.)"
        >
          BBA
        </button>

        <button
          className={`btn btn-sm ${selectedAlgorithm === 'THROUGHPUT_EWMA' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setSelectedAlgorithm('THROUGHPUT_EWMA')}
          title="Traditional EWMA Rate-Based Adaptation"
        >
          EWMA
        </button>

        <button
          className={`btn btn-sm ${selectedAlgorithm === 'NAIVE_STATIC' ? 'btn-primary' : 'btn-secondary'}`}
          onClick={() => setSelectedAlgorithm('NAIVE_STATIC')}
          title="Fixed 1080p without adaptation (Baseline Control)"
        >
          Static 1080p
        </button>
      </div>

      {/* Right Side: View Mode & Modals */}
      <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
        {/* Device Telemetry Pill */}
        <div className="glass-panel" style={{
          display: 'flex',
          alignItems: 'center',
          gap: '0.75rem',
          padding: '0.4rem 0.85rem',
          borderRadius: '10px'
        }}>
          {/* Network Indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.8rem' }}>
            <Wifi size={14} color="var(--accent-cyan)" />
            <span className="mono" style={{ color: 'var(--accent-cyan)', fontWeight: 600, textTransform: 'uppercase' }}>
              {networkType}
            </span>
          </div>

          <div style={{ width: '1px', height: '14px', background: 'var(--border-subtle)' }} />

          {/* Battery Indicator */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', fontSize: '0.8rem' }}>
            {isCharging ? (
              <BatteryCharging size={15} color="var(--accent-emerald)" />
            ) : (
              <Battery size={15} color={batteryLevel < 20 ? 'var(--accent-rose)' : 'var(--accent-emerald)'} />
            )}
            <span className="mono" style={{ 
              color: batteryLevel < 20 ? 'var(--accent-rose)' : '#e2e8f0', 
              fontWeight: 600 
            }}>
              {batteryLevel !== null ? `${batteryLevel}%` : '85%'}
            </span>
          </div>
        </div>

        {/* View Switcher: Mobile Phone vs Desktop Console */}
        <div className="glass-panel" style={{ display: 'flex', padding: '0.25rem', borderRadius: '10px' }}>
          <button
            onClick={() => setViewMode('mobile')}
            className={`btn btn-sm ${viewMode === 'mobile' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '0.4rem 0.75rem' }}
            title="Mobile Device Viewport Preview"
          >
            <Smartphone size={15} />
            <span>Mobile</span>
          </button>
          <button
            onClick={() => setViewMode('desktop')}
            className={`btn btn-sm ${viewMode === 'desktop' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ padding: '0.4rem 0.75rem' }}
            title="Expanded Desktop Command Center"
          >
            <Monitor size={15} />
            <span>Console</span>
          </button>
        </div>

        {/* Live Network Monitor Modal Trigger */}
        <button
          className="btn btn-secondary btn-sm"
          onClick={onOpenNetworkMonitor}
          style={{ 
            borderColor: 'rgba(0, 242, 254, 0.4)', 
            color: 'var(--accent-cyan)',
            background: 'rgba(0, 242, 254, 0.08)' 
          }}
          title="Open Live Network & Channel Telemetry (Bandwidth, Latency, Loss, Jitter)"
        >
          <Activity size={15} color="var(--accent-cyan)" />
          <span className="pulse-dot online" style={{ width: '6px', height: '6px' }} />
          <span>Live Network</span>
          {currentLatencyMs && (
            <span className="mono" style={{ fontSize: '0.7rem', color: '#94a3b8', marginLeft: '2px' }}>
              ({currentLatencyMs}ms)
            </span>
          )}
        </button>

        {/* A/B Benchmark Modal Trigger */}
        <button
          className="btn btn-secondary btn-sm"
          onClick={onOpenBenchmark}
          style={{ borderColor: 'rgba(168, 85, 247, 0.4)', color: '#d8b4fe' }}
        >
          <GitCompare size={15} color="var(--accent-violet)" />
          <span>A/B Benchmark</span>
        </button>

        {/* Capstone Documentation Modal Trigger */}
        <button
          className="btn btn-outline-cyan btn-sm"
          onClick={onOpenExplainer}
        >
          <BookOpen size={15} />
          <span>Thesis Guide</span>
        </button>
      </div>
    </header>
  );
}
