import React from 'react';
import { 
  X, 
  BookOpen, 
  Layers, 
  Radio, 
  CheckCircle2, 
  Code2 
} from 'lucide-react';

export default function ArchitectureExplainerModal({ isOpen, onClose }) {
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '960px' }}>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '1rem', marginBottom: '1.5rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
            <div style={{ width: '40px', height: '40px', borderRadius: '12px', background: 'rgba(0, 242, 254, 0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <BookOpen size={22} color="var(--accent-cyan)" />
            </div>
            <div>
              <h2 style={{ fontSize: '1.3rem', margin: 0 }}>
                MediaFlow Capstone Project Architecture & Theory Guide
              </h2>
              <p style={{ fontSize: '0.8rem', color: '#94a3b8', margin: 0 }}>
                Mobile Computing & Multimedia Systems Implementation Reference
              </p>
            </div>
          </div>
          <button onClick={onClose} className="btn btn-secondary btn-sm" style={{ padding: '0.4rem' }}>
            <X size={18} />
          </button>
        </div>

        {/* Content Body */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem', maxHeight: '72vh', overflowY: 'auto', paddingRight: '0.5rem' }}>
          {/* Section 1: Research Motivation & Problem Statement */}
          <div className="glass-panel" style={{ padding: '1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.5rem' }}>
              <Radio size={18} color="var(--accent-cyan)" />
              <h3 style={{ fontSize: '1rem', color: 'var(--accent-cyan)' }}>
                1. The Mobile Computing Problem Statement
              </h3>
            </div>
            <p style={{ fontSize: '0.82rem', color: '#cbd5e1', lineHeight: 1.6 }}>
              Unlike fixed broadband networks, mobile multimedia streaming suffers from severe channel non-stationarity:
              signal fading, cell tower handovers (4G/5G), and dead-zones (subways, elevators). 
              Furthermore, mobile devices operate under strict physical constraints: 
              finite battery charge, limited thermal dissipation budgets, and GPU/decoder thermal throttling.
              Conventional Adaptive Bitrate (ABR) players either freeze during sudden drops or drain battery rapidly by blindly requesting 4K/1080p.
            </p>
          </div>

          {/* Section 2: Mathematical Formulations */}
          <div className="glass-panel" style={{ padding: '1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}>
              <Code2 size={18} color="var(--accent-violet)" />
              <h3 style={{ fontSize: '1rem', color: 'var(--accent-violet)' }}>
                2. Core Mathematical Formulations
              </h3>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1rem' }}>
              {/* Formula A */}
              <div style={{ background: 'rgba(0, 0, 0, 0.4)', borderRadius: '10px', padding: '0.85rem', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#38bdf8', marginBottom: '4px' }}>
                  A. Throughput EWMA Estimator
                </div>
                <div className="mono" style={{ fontSize: '0.75rem', background: 'rgba(255,255,255,0.05)', padding: '6px 8px', borderRadius: '6px', color: '#f1f5f9' }}>
                  T̂_t = (1 - α) · T̂_(t-1) + α · T_t
                </div>
                <p style={{ fontSize: '0.72rem', color: '#94a3b8', marginTop: '6px' }}>
                  Uses smoothing factor α = 0.85 to filter transient cellular spikes while reacting fast to drops.
                </p>
              </div>

              {/* Formula B */}
              <div style={{ background: 'rgba(0, 0, 0, 0.4)', borderRadius: '10px', padding: '0.85rem', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-emerald)', marginBottom: '4px' }}>
                  B. Buffer-Based Cushion Scaling (BBA)
                </div>
                <div className="mono" style={{ fontSize: '0.75rem', background: 'rgba(255,255,255,0.05)', padding: '6px 8px', borderRadius: '6px', color: '#f1f5f9' }}>
                  R(B_t) = R_min + ((B_t - B_res) / B_cush) · (R_max - R_min)
                </div>
                <p style={{ fontSize: '0.72rem', color: '#94a3b8', marginTop: '6px' }}>
                  Reservoir floor: 4.0s (emergency 240p). Cushion: 4s - 16s. Safe zone: &gt; 16s (peak quality).
                </p>
              </div>

              {/* Formula C */}
              <div style={{ background: 'rgba(0, 0, 0, 0.4)', borderRadius: '10px', padding: '0.85rem', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 700, color: 'var(--accent-amber)', marginBottom: '4px' }}>
                  C. ITU-T P.1203 Standardized QoE (MOS)
                </div>
                <div className="mono" style={{ fontSize: '0.75rem', background: 'rgba(255,255,255,0.05)', padding: '6px 8px', borderRadius: '6px', color: '#f1f5f9' }}>
                  QoE = q(R) - μ · T_stall - λ · ΔR_switch
                </div>
                <p style={{ fontSize: '0.72rem', color: '#94a3b8', marginTop: '6px' }}>
                  Heavily penalizes video stalls (μ = 4.3) and frequent oscillation switching (λ = 1.0).
                </p>
              </div>

              {/* Formula D */}
              <div style={{ background: 'rgba(0, 0, 0, 0.4)', borderRadius: '10px', padding: '0.85rem', border: '1px solid rgba(255, 255, 255, 0.06)' }}>
                <div style={{ fontSize: '0.78rem', fontWeight: 700, color: '#f472b6', marginBottom: '4px' }}>
                  D. Mobile Energy Consumption Model
                </div>
                <div className="mono" style={{ fontSize: '0.75rem', background: 'rgba(255,255,255,0.05)', padding: '6px 8px', borderRadius: '6px', color: '#f1f5f9' }}>
                  P_total = P_base + P_decoder(res) + P_radio(net)
                </div>
                <p style={{ fontSize: '0.72rem', color: '#94a3b8', marginTop: '6px' }}>
                  Down-capping to 720p/480p at &lt; 20% battery saves ~47% of total device power draw.
                </p>
              </div>
            </div>
          </div>

          {/* Section 3: System Architecture Modules */}
          <div className="glass-panel" style={{ padding: '1.25rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', marginBottom: '0.75rem' }}>
              <Layers size={18} color="var(--accent-cyan)" />
              <h3 style={{ fontSize: '1rem', color: 'var(--accent-cyan)' }}>
                3. High-Level System Architecture
              </h3>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                <CheckCircle2 size={16} color="var(--accent-emerald)" style={{ marginTop: '2px', flexShrink: 0 }} />
                <div style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>
                  <strong style={{ color: '#fff' }}>MediaSource Extensions (MSE) & HLS Segment Parser:</strong> Ingests fragmented MP4 video segments across a multi-bitrate ladder (240p to 1080p).
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                <CheckCircle2 size={16} color="var(--accent-emerald)" style={{ marginTop: '2px', flexShrink: 0 }} />
                <div style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>
                  <strong style={{ color: '#fff' }}>Mobile Context Engine:</strong> Interfaces with native W3C Web APIs including <code className="mono">navigator.getBattery()</code>, <code className="mono">navigator.connection</code>, and <code className="mono">requestVideoFrameCallback()</code>.
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                <CheckCircle2 size={16} color="var(--accent-emerald)" style={{ marginTop: '2px', flexShrink: 0 }} />
                <div style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>
                  <strong style={{ color: '#fff' }}>Multi-Factor Adaptation Controller:</strong> Computes the consensus level by balancing channel capacity, buffer depletion velocity (dB/dt), hardware frame drops, and battery health.
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'flex-start', gap: '0.75rem' }}>
                <CheckCircle2 size={16} color="var(--accent-emerald)" style={{ marginTop: '2px', flexShrink: 0 }} />
                <div style={{ fontSize: '0.8rem', color: '#cbd5e1' }}>
                  <strong style={{ color: '#fff' }}>Interactive Mobility & Channel Emulator:</strong> Emulates 5G mmWave bursts, 4G highway handovers, subway tunnel blackouts, and crowded stadium congestion.
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div style={{ marginTop: '1.25rem', paddingTop: '1rem', borderTop: '1px solid var(--border-subtle)', display: 'flex', justifyContent: 'flex-end' }}>
          <button onClick={onClose} className="btn btn-primary">
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
}
