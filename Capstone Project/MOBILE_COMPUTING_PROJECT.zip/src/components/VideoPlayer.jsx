import React, { useEffect, useRef, useState } from 'react';
import Hls from 'hls.js';
import { 
  Play, 
  Pause, 
  Volume2, 
  VolumeX, 
  Maximize, 
  Zap, 
  AlertTriangle,
  Film,
  Activity,
  Layers
} from 'lucide-react';
import { DEFAULT_BITRATE_LADDER, SAMPLE_STREAMS } from '../algorithms/abrEngine';

export default function VideoPlayer({
  selectedStreamUrl,
  setSelectedStreamUrl,
  currentLevelIndex,
  onQualityLevelAssigned,
  onTelemetryUpdate,
  isSimulatorStallActive,
  isLowBatteryThrottled,
  algorithmDecisionReason
}) {
  const videoRef = useRef(null);
  const hlsRef = useRef(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [isMuted, setIsMuted] = useState(true);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [bufferLength, setBufferLength] = useState(0);
  const [isStalled, setIsStalled] = useState(false);
  const [stallDuration, setStallDuration] = useState(0);
  const [availableLevels, setAvailableLevels] = useState(DEFAULT_BITRATE_LADDER);
  const stallTimerRef = useRef(null);

  // Initialize or re-initialize HLS stream
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    // Clean up previous instance
    if (hlsRef.current) {
      hlsRef.current.destroy();
      hlsRef.current = null;
    }

    if (Hls.isSupported()) {
      const hls = new Hls({
        capLevelToPlayerSize: false,
        autoStartLoad: true,
        startLevel: 1, // Start at 360p for mobile speed
        debug: false
      });

      hlsRef.current = hls;
      hls.loadSource(selectedStreamUrl);
      hls.attachMedia(video);

      hls.on(Hls.Events.MANIFEST_PARSED, (event, data) => {
        if (data.levels && data.levels.length > 0) {
          const parsed = data.levels.map((lvl, idx) => ({
            level: idx,
            resolution: `${lvl.height || 360}p`,
            width: lvl.width || 640,
            height: lvl.height || 360,
            bitrate: lvl.bitrate || 800000,
            fps: lvl.frameRate || 30,
            label: `${lvl.height || 360}p (${((lvl.bitrate || 800000) / 1000).toFixed(0)} kbps)`
          }));
          setAvailableLevels(parsed);
          onQualityLevelAssigned(parsed, 1);
        }
        // Auto play muted
        video.play().then(() => setIsPlaying(true)).catch(() => setIsPlaying(false));
      });

      hls.on(Hls.Events.LEVEL_SWITCHED, () => {
        // Level switched callback
      });

      hls.on(Hls.Events.ERROR, (_event, data) => {
        if (data.fatal) {
          switch (data.type) {
            case Hls.ErrorTypes.NETWORK_ERROR:
              hls.startLoad();
              break;
            case Hls.ErrorTypes.MEDIA_ERROR:
              hls.recoverMediaError();
              break;
            default:
              hls.destroy();
              break;
          }
        }
      });
    } else if (video.canPlayType('application/vnd.apple.mpegurl')) {
      // Native Safari HLS
      video.src = selectedStreamUrl;
      video.addEventListener('loadedmetadata', () => {
        video.play().then(() => setIsPlaying(true)).catch(() => {});
      });
    }

    return () => {
      if (hlsRef.current) {
        hlsRef.current.destroy();
        hlsRef.current = null;
      }
    };
  }, [selectedStreamUrl, onQualityLevelAssigned]);

  // Synchronize HLS target quality level when ABR engine changes it
  useEffect(() => {
    if (hlsRef.current && currentLevelIndex !== undefined) {
      if (hlsRef.current.currentLevel !== currentLevelIndex) {
        hlsRef.current.currentLevel = currentLevelIndex;
      }
    }
  }, [currentLevelIndex]);

  // Handle simulated blackout stall (when simulator hits a tunnel or 0 kbps)
  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    if (isSimulatorStallActive) {
      video.pause();
      setIsStalled(true);
    } else if (isPlaying && video.paused) {
      video.play().catch(() => {});
      setIsStalled(false);
    }
  }, [isSimulatorStallActive, isPlaying]);

  // High-frequency telemetry sampling loop (buffer, time, dropped frames)
  useEffect(() => {
    const interval = setInterval(() => {
      const video = videoRef.current;
      if (!video) return;

      // Calculate forward buffer length in seconds
      let currentBuffer = 0;
      if (video.buffered && video.buffered.length > 0) {
        const time = video.currentTime;
        for (let i = 0; i < video.buffered.length; i++) {
          if (video.buffered.start(i) <= time && time <= video.buffered.end(i)) {
            currentBuffer = video.buffered.end(i) - time;
            break;
          }
        }
      }
      setBufferLength(currentBuffer);
      setCurrentTime(video.currentTime);
      setDuration(video.duration || 1);

      // Frame drop detection using HTMLMediaElement playback quality API
      const dropped = video.getVideoPlaybackQuality ? video.getVideoPlaybackQuality().droppedVideoFrames : 0;
      const total = video.getVideoPlaybackQuality ? video.getVideoPlaybackQuality().totalVideoFrames : 100;

      // Propagate telemetry up to parent
      onTelemetryUpdate({
        currentTime: video.currentTime,
        duration: video.duration || 1,
        bufferSeconds: currentBuffer,
        isStalled: isStalled || video.readyState < 3,
        droppedFrames: dropped,
        totalFrames: total
      });
    }, 400);

    return () => clearInterval(interval);
  }, [isStalled, onTelemetryUpdate]);

  // Track stall duration timer
  useEffect(() => {
    if (isStalled) {
      const startTime = Date.now();
      stallTimerRef.current = setInterval(() => {
        setStallDuration(((Date.now() - startTime) / 1000).toFixed(1));
      }, 100);
    } else {
      if (stallTimerRef.current) clearInterval(stallTimerRef.current);
      setStallDuration(0);
    }
    return () => {
      if (stallTimerRef.current) clearInterval(stallTimerRef.current);
    };
  }, [isStalled]);

  // Video event handlers
  const handleWaiting = () => setIsStalled(true);
  const handlePlaying = () => setIsStalled(false);
  const handleTogglePlay = () => {
    const video = videoRef.current;
    if (!video) return;
    if (video.paused) {
      video.play().then(() => setIsPlaying(true)).catch(() => {});
    } else {
      video.pause();
      setIsPlaying(false);
    }
  };

  const handleToggleMute = () => {
    const video = videoRef.current;
    if (!video) return;
    video.muted = !video.muted;
    setIsMuted(video.muted);
  };

  const handleSeek = (e) => {
    const video = videoRef.current;
    if (!video || !duration) return;
    const clickX = e.nativeEvent.offsetX;
    const barWidth = e.currentTarget.offsetWidth;
    const targetTime = (clickX / barWidth) * duration;
    video.currentTime = targetTime;
  };

  const currentLevelObj = availableLevels[currentLevelIndex] || availableLevels[0] || DEFAULT_BITRATE_LADDER[0];

  return (
    <div className="glass-panel highlight-cyan" style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {/* Top Stream Selector Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0.75rem 1rem',
        borderBottom: '1px solid var(--border-subtle)',
        background: 'rgba(5, 8, 16, 0.5)',
        flexWrap: 'wrap',
        gap: '0.5rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Film size={16} color="var(--accent-cyan)" />
          <span style={{ fontSize: '0.85rem', fontWeight: 600 }}>Active Stream:</span>
          <select
            value={selectedStreamUrl}
            onChange={(e) => setSelectedStreamUrl(e.target.value)}
            style={{
              background: 'rgba(15, 23, 42, 0.9)',
              color: '#f8fafc',
              border: '1px solid var(--border-subtle)',
              borderRadius: '8px',
              padding: '0.35rem 0.65rem',
              fontSize: '0.8rem',
              fontFamily: 'var(--font-main)',
              cursor: 'pointer',
              outline: 'none'
            }}
          >
            {SAMPLE_STREAMS.map((s, idx) => (
              <option key={idx} value={s.url}>
                {s.name} ({s.genre})
              </option>
            ))}
          </select>
        </div>

        {/* Live ABR Decision Overlay Badge */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {isLowBatteryThrottled && (
            <span className="badge badge-amber" title="MediaFlow downscaled quality to protect mobile battery">
              <Zap size={11} /> Power Saver Cap
            </span>
          )}
          <span className="badge badge-cyan">
            <Layers size={11} />
            {currentLevelObj.resolution} · {((currentLevelObj.bitrate) / 1000).toFixed(0)} kbps
          </span>
        </div>
      </div>

      {/* Video Viewport Wrapper */}
      <div style={{ position: 'relative', width: '100%', background: '#000', minHeight: '260px', flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', overflow: 'hidden' }}>
        <video
          ref={videoRef}
          style={{ width: '100%', height: '100%', objectFit: 'contain', display: 'block' }}
          muted={isMuted}
          playsInline
          onWaiting={handleWaiting}
          onPlaying={handlePlaying}
          onTimeUpdate={() => {
            if (videoRef.current) setCurrentTime(videoRef.current.currentTime);
          }}
        />

        {/* Rebuffering Stall Overlay */}
        {(isStalled || isSimulatorStallActive) && (
          <div style={{
            position: 'absolute',
            inset: 0,
            background: 'rgba(5, 8, 16, 0.75)',
            backdropFilter: 'blur(4px)',
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '0.75rem',
            zIndex: 10
          }}>
            <div style={{
              width: '46px',
              height: '46px',
              borderRadius: '50%',
              border: '3px solid rgba(255, 77, 109, 0.2)',
              borderTopColor: 'var(--accent-rose)',
              animation: 'spin 0.8s linear infinite'
            }} />
            <div style={{ textAlign: 'center' }}>
              <div style={{ color: 'var(--accent-rose)', fontWeight: 700, fontSize: '0.95rem', display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
                <AlertTriangle size={16} />
                <span>MOBILE REBUFFERING STALL</span>
              </div>
              <div style={{ fontSize: '0.8rem', color: '#94a3b8' }}>
                Stall Duration: <span className="mono" style={{ color: '#fff', fontWeight: 700 }}>{stallDuration}s</span>
              </div>
            </div>
          </div>
        )}

        {/* Top-Right HUD Badge: Resolution & FPS */}
        <div style={{
          position: 'absolute',
          top: '12px',
          right: '12px',
          display: 'flex',
          gap: '6px',
          zIndex: 5
        }}>
          <div style={{
            background: 'rgba(10, 15, 26, 0.75)',
            backdropFilter: 'blur(8px)',
            border: '1px solid var(--border-subtle)',
            borderRadius: '6px',
            padding: '2px 8px',
            fontSize: '0.72rem',
            fontFamily: 'var(--font-mono)',
            color: '#38bdf8'
          }}>
            {currentLevelObj.width}x{currentLevelObj.height} @ {currentLevelObj.fps}fps
          </div>
        </div>

        {/* Bottom Floating Reason Pill */}
        {algorithmDecisionReason && (
          <div style={{
            position: 'absolute',
            bottom: '12px',
            left: '12px',
            background: 'rgba(10, 15, 26, 0.8)',
            backdropFilter: 'blur(8px)',
            border: '1px solid rgba(0, 242, 254, 0.25)',
            borderRadius: '6px',
            padding: '3px 10px',
            fontSize: '0.72rem',
            color: '#e2e8f0',
            display: 'flex',
            alignItems: 'center',
            gap: '0.4rem',
            maxWidth: '85%',
            overflow: 'hidden',
            textOverflow: 'ellipsis',
            whiteSpace: 'nowrap',
            zIndex: 5
          }}>
            <Activity size={12} color="var(--accent-cyan)" />
            <span>ABR: {algorithmDecisionReason}</span>
          </div>
        )}
      </div>

      {/* Buffer Reservoir Progress Bar */}
      <div style={{ padding: '0 1rem', marginTop: '0.5rem' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.72rem', color: '#94a3b8', marginBottom: '3px' }}>
          <span>Buffer Health: <strong className="mono" style={{ color: bufferLength < 4 ? 'var(--accent-rose)' : bufferLength < 10 ? 'var(--accent-amber)' : 'var(--accent-emerald)' }}>{bufferLength.toFixed(1)}s</strong></span>
          <span>Target Reservoir: <strong>16.0s</strong></span>
        </div>
        <div style={{ width: '100%', height: '6px', background: 'rgba(255, 255, 255, 0.08)', borderRadius: '3px', overflow: 'hidden', position: 'relative' }}>
          {/* Reservoir threshold mark (4s) */}
          <div style={{ position: 'absolute', left: '25%', top: 0, bottom: 0, width: '2px', background: 'rgba(255, 77, 109, 0.5)' }} title="Emergency Floor (4s)" />
          {/* Fill Bar */}
          <div style={{
            height: '100%',
            width: `${Math.min(100, (bufferLength / 16) * 100)}%`,
            background: bufferLength < 4 ? 'var(--accent-rose)' : bufferLength < 10 ? 'var(--accent-amber)' : 'var(--accent-emerald)',
            transition: 'width 0.3s ease, background 0.3s ease'
          }} />
        </div>
      </div>

      {/* Video Controls Bar */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'space-between',
        padding: '0.75rem 1rem',
        gap: '0.75rem'
      }}>
        {/* Play / Pause */}
        <button
          onClick={handleTogglePlay}
          className="btn btn-secondary btn-sm"
          style={{ width: '36px', height: '36px', padding: 0 }}
        >
          {isPlaying ? <Pause size={17} /> : <Play size={17} style={{ marginLeft: '2px' }} />}
        </button>

        {/* Timeline Slider */}
        <div style={{ flex: 1, display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <span className="mono" style={{ fontSize: '0.72rem', color: '#94a3b8' }}>
            {formatTime(currentTime)}
          </span>
          <div
            onClick={handleSeek}
            style={{
              flex: 1,
              height: '5px',
              background: 'rgba(255, 255, 255, 0.12)',
              borderRadius: '3px',
              cursor: 'pointer',
              position: 'relative'
            }}
          >
            <div style={{
              width: `${(currentTime / (duration || 1)) * 100}%`,
              height: '100%',
              background: 'var(--grad-cyan-blue)',
              borderRadius: '3px'
            }} />
          </div>
          <span className="mono" style={{ fontSize: '0.72rem', color: '#94a3b8' }}>
            {formatTime(duration)}
          </span>
        </div>

        {/* Volume & Fullscreen */}
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
          <button
            onClick={handleToggleMute}
            className="btn btn-secondary btn-sm"
            style={{ width: '34px', height: '34px', padding: 0 }}
            title={isMuted ? 'Unmute Audio' : 'Mute Audio'}
          >
            {isMuted ? <VolumeX size={15} color="var(--accent-rose)" /> : <Volume2 size={15} />}
          </button>
          <button
            onClick={() => {
              if (videoRef.current) {
                if (videoRef.current.requestFullscreen) videoRef.current.requestFullscreen();
              }
            }}
            className="btn btn-secondary btn-sm"
            style={{ width: '34px', height: '34px', padding: 0 }}
            title="Fullscreen"
          >
            <Maximize size={15} />
          </button>
        </div>
      </div>
    </div>
  );
}

function formatTime(seconds) {
  if (isNaN(seconds)) return '00:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
}
