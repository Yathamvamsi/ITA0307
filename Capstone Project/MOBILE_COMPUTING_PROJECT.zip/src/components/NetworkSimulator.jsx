import React from 'react';
import { 
  Radio, 
  Gauge, 
  Clock, 
  ShieldAlert, 
  TrainFront, 
  Car, 
  Users, 
  BatteryLow, 
  Battery,
  BatteryCharging,
  Activity,
  Sparkles 
} from 'lucide-react';
import { MOBILE_SCENARIOS } from '../algorithms/abrEngine';

export default function NetworkSimulator({
  currentScenario,
  onSelectScenario,
  simulatedBandwidthKbps,
  setSimulatedBandwidthKbps,
  simulatedLatencyMs,
  setSimulatedLatencyMs,
  simulatedPacketLossPct,
  setSimulatedPacketLossPct,
  simulatedJitterMs,
  setSimulatedJitterMs,
  batteryLevel,
  setBatteryLevel,
  isCharging,
  setIsCharging,
  onTriggerBlackoutTunnel,
  isBlackoutActive
}) {
  return (
    <div className="glass-panel" style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Radio size={18} color="var(--accent-cyan)" />
          <h3 style={{ fontSize: '1rem', fontWeight: 700, margin: 0 }}>
            Mobile Network & Mobility Simulator
          </h3>
        </div>
        <span className="badge badge-cyan">CHANNEL EMULATOR</span>
      </div>

      {/* Scenario Presets Quick Selector */}
      <div>
        <div style={{ fontSize: '0.78rem', color: '#94a3b8', marginBottom: '0.5rem', fontWeight: 600 }}>
          MOBILITY SCENARIO PRESETS:
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(130px, 1fr))', gap: '0.5rem' }}>
          {/* 5G */}
          <button
            onClick={() => onSelectScenario(MOBILE_SCENARIOS.STABLE_5G)}
            className={`btn btn-sm ${currentScenario?.id === 'STABLE_5G' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ flexDirection: 'column', padding: '0.6rem 0.4rem', height: 'auto', gap: '0.2rem' }}
          >
            <Sparkles size={16} />
            <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>5G mmWave</span>
            <span style={{ fontSize: '0.65rem', opacity: 0.8 }}>35 Mbps · 18ms</span>
          </button>

          {/* Highway Handover */}
          <button
            onClick={() => onSelectScenario(MOBILE_SCENARIOS.HIGHWAY_HANDOVER)}
            className={`btn btn-sm ${currentScenario?.id === 'HIGHWAY_HANDOVER' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ flexDirection: 'column', padding: '0.6rem 0.4rem', height: 'auto', gap: '0.2rem' }}
          >
            <Car size={16} />
            <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>Highway Handover</span>
            <span style={{ fontSize: '0.65rem', opacity: 0.8 }}>4.5 Mbps · 85ms</span>
          </button>

          {/* Subway Transit */}
          <button
            onClick={() => onSelectScenario(MOBILE_SCENARIOS.SUBWAY_COMMUTE)}
            className={`btn btn-sm ${currentScenario?.id === 'SUBWAY_COMMUTE' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ flexDirection: 'column', padding: '0.6rem 0.4rem', height: 'auto', gap: '0.2rem' }}
          >
            <TrainFront size={16} />
            <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>Subway Tunnel</span>
            <span style={{ fontSize: '0.65rem', opacity: 0.8 }}>1.1 Mbps · 240ms</span>
          </button>

          {/* Stadium Congestion */}
          <button
            onClick={() => onSelectScenario(MOBILE_SCENARIOS.STADIUM_CONGESTION)}
            className={`btn btn-sm ${currentScenario?.id === 'STADIUM_CONGESTION' ? 'btn-primary' : 'btn-secondary'}`}
            style={{ flexDirection: 'column', padding: '0.6rem 0.4rem', height: 'auto', gap: '0.2rem' }}
          >
            <Users size={16} />
            <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>Stadium Rush</span>
            <span style={{ fontSize: '0.65rem', opacity: 0.8 }}>750 kbps · 380ms</span>
          </button>

          {/* Low Battery */}
          <button
            onClick={() => onSelectScenario(MOBILE_SCENARIOS.BATTERY_CRITICAL)}
            className={`btn btn-sm ${currentScenario?.id === 'BATTERY_CRITICAL' ? 'btn-purple' : 'btn-secondary'}`}
            style={{ flexDirection: 'column', padding: '0.6rem 0.4rem', height: 'auto', gap: '0.2rem' }}
          >
            <BatteryLow size={16} />
            <span style={{ fontSize: '0.75rem', fontWeight: 700 }}>Low Battery 12%</span>
            <span style={{ fontSize: '0.65rem', opacity: 0.8 }}>Power-Saver Cap</span>
          </button>
        </div>
      </div>

      {/* Manual Fine-Tuning Sliders */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: '0.85rem' }}>
        {/* Bandwidth */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '4px' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#cbd5e1' }}>
              <Gauge size={14} color="var(--accent-cyan)" /> Bandwidth Throttler:
            </span>
            <strong className="mono" style={{ color: 'var(--accent-cyan)' }}>
              {simulatedBandwidthKbps >= 1000 ? `${(simulatedBandwidthKbps / 1000).toFixed(1)} Mbps` : `${simulatedBandwidthKbps} kbps`}
            </strong>
          </div>
          <input
            type="range"
            min="300"
            max="40000"
            step="100"
            value={simulatedBandwidthKbps}
            onChange={(e) => setSimulatedBandwidthKbps(Number(e.target.value))}
          />
        </div>

        {/* Latency RTT */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '4px' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#cbd5e1' }}>
              <Clock size={14} color="var(--accent-amber)" /> Round-Trip Latency (RTT):
            </span>
            <strong className="mono" style={{ color: simulatedLatencyMs > 200 ? 'var(--accent-rose)' : 'var(--accent-amber)' }}>
              {simulatedLatencyMs} ms
            </strong>
          </div>
          <input
            type="range"
            min="10"
            max="600"
            step="10"
            value={simulatedLatencyMs}
            onChange={(e) => setSimulatedLatencyMs(Number(e.target.value))}
          />
        </div>

        {/* Packet Loss */}
        <div>
          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '4px' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#cbd5e1' }}>
              <ShieldAlert size={14} color="var(--accent-rose)" /> Packet Drop Rate:
            </span>
            <strong className="mono" style={{ color: simulatedPacketLossPct > 5 ? 'var(--accent-rose)' : '#cbd5e1' }}>
              {simulatedPacketLossPct.toFixed(1)} %
            </strong>
          </div>
          <input
            type="range"
            min="0"
            max="25"
            step="0.5"
            value={simulatedPacketLossPct}
            onChange={(e) => setSimulatedPacketLossPct(Number(e.target.value))}
          />
        </div>

        {/* Jitter */}
        {setSimulatedJitterMs && (
          <div>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.78rem', marginBottom: '4px' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#cbd5e1' }}>
                <Activity size={14} color="var(--accent-violet)" /> Mobile Jitter Variation:
              </span>
              <strong className="mono" style={{ color: simulatedJitterMs > 50 ? 'var(--accent-rose)' : 'var(--accent-violet)' }}>
                ±{simulatedJitterMs} ms
              </strong>
            </div>
            <input
              type="range"
              min="0"
              max="200"
              step="5"
              value={simulatedJitterMs}
              onChange={(e) => setSimulatedJitterMs(Number(e.target.value))}
            />
          </div>
        )}

        {/* Mobile Battery Emulation Slider */}
        {setBatteryLevel && (
          <div style={{ paddingTop: '0.35rem', borderTop: '1px dashed var(--border-subtle)' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: '0.78rem', marginBottom: '4px' }}>
              <span style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', color: '#cbd5e1' }}>
                {isCharging ? <BatteryCharging size={14} color="var(--accent-emerald)" /> : <Battery size={14} color={batteryLevel < 20 ? 'var(--accent-rose)' : 'var(--accent-emerald)'} />}
                Mobile Battery Level:
              </span>
              <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                {setIsCharging && (
                  <button
                    onClick={() => setIsCharging(!isCharging)}
                    className="btn btn-secondary btn-sm"
                    style={{ fontSize: '0.65rem', padding: '0.15rem 0.4rem' }}
                    title="Toggle AC Power Charging"
                  >
                    {isCharging ? 'AC Plugged' : 'On Battery'}
                  </button>
                )}
                <strong className="mono" style={{ color: batteryLevel < 20 ? 'var(--accent-rose)' : 'var(--accent-emerald)' }}>
                  {batteryLevel}%
                </strong>
              </div>
            </div>
            <input
              type="range"
              min="5"
              max="100"
              step="1"
              value={batteryLevel}
              onChange={(e) => setBatteryLevel(Number(e.target.value))}
            />
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.65rem', color: '#64748b', marginTop: '2px' }}>
              <span>5% (Critical Cap)</span>
              <span>15% (480p Saver)</span>
              <span>25% (720p Cap)</span>
              <span>100% (Unrestricted)</span>
            </div>
          </div>
        )}
      </div>

      {/* Instant Action: Trigger Subway Tunnel Blackout */}
      <div style={{ paddingTop: '0.5rem', borderTop: '1px solid var(--border-subtle)' }}>
        <button
          onClick={onTriggerBlackoutTunnel}
          disabled={isBlackoutActive}
          className="btn btn-secondary"
          style={{
            width: '100%',
            borderColor: isBlackoutActive ? 'var(--accent-rose)' : 'rgba(255, 77, 109, 0.4)',
            color: isBlackoutActive ? 'var(--accent-rose)' : '#fca5a5',
            background: isBlackoutActive ? 'rgba(255, 77, 109, 0.15)' : 'rgba(255, 77, 109, 0.05)'
          }}
        >
          <TrainFront size={16} color="var(--accent-rose)" />
          <span>
            {isBlackoutActive ? 'Simulating 4s Tunnel Blackout (0 kbps)...' : 'Test Sudden Tunnel Blackout (4s Drop)'}
          </span>
        </button>
      </div>
    </div>
  );
}
