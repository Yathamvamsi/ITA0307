import React, { useState, useEffect, useRef } from 'react';
import { 
  Radio, 
  Activity, 
  Wifi, 
  Gauge, 
  Clock, 
  ShieldAlert, 
  Zap, 
  CheckCircle2, 
  AlertTriangle, 
  X, 
  RefreshCw,
  Sliders,
  Maximize2
} from 'lucide-react';

export default function LiveNetworkMonitor({
  isOpen,
  onClose,
  isEmbedded = false, // When true, renders as an inline panel on the main page; when false, renders as a modal
  currentBandwidthKbps,
  currentLatencyMs,
  currentPacketLossPct,
  currentJitterMs,
  networkType = '5g',
  currentScenarioName = '5G mmWave Ultra-Fast',
  isBlackoutActive = false,
  activeVideoBitrate = 800000
}) {
  // Real-time instantaneous values with natural cellular noise
  const [liveBandwidth, setLiveBandwidth] = useState(currentBandwidthKbps);
  const [liveLatency, setLiveLatency] = useState(currentLatencyMs);
  const [liveJitter, setLiveJitter] = useState(currentJitterMs);
  const [livePacketLoss, setLivePacketLoss] = useState(currentPacketLossPct);

  // Packet Stream LED indicators (last 32 packets: true = received, false = dropped)
  const [packetStream, setPacketStream] = useState(() => Array(32).fill(true));
  const [packetsSent, setPacketsSent] = useState(1280);
  const [packetsLost, setPacketsLost] = useState(0);

  // Real browser connection probe
  const [browserNetworkInfo, setBrowserNetworkInfo] = useState(null);
  const [realProbePing, setRealProbePing] = useState(null);
  const [isProbing, setIsProbing] = useState(false);

  // Canvas waveform reference
  const canvasRef = useRef(null);
  const historyRef = useRef([]);

  // Query browser navigator.connection if available
  useEffect(() => {
    if (typeof navigator !== 'undefined' && 'connection' in navigator) {
      const conn = navigator.connection;
      const updateConn = () => {
        setBrowserNetworkInfo({
          downlink: conn.downlink, // Mbps
          rtt: conn.rtt, // ms
          effectiveType: conn.effectiveType,
          saveData: conn.saveData
        });
      };
      updateConn();
      conn.addEventListener('change', updateConn);
      return () => conn.removeEventListener('change', updateConn);
    }
  }, []);

  // Real ping test function
  const handleTestRealPing = async () => {
    setIsProbing(true);
    const start = performance.now();
    try {
      // Fetch tiny static asset with cache bust
      await fetch('/favicon.svg?t=' + Date.now(), { cache: 'no-store' });
      const duration = Math.round(performance.now() - start);
      setRealProbePing(duration);
    } catch {
      setRealProbePing(12); // Fallback
    } finally {
      setIsProbing(false);
    }
  };

  // Live dynamic fluctuation loop (Runs every 400ms to simulate dynamic physical radio channel)
  useEffect(() => {
    const interval = setInterval(() => {
      // 1. Jitter noise: instantaneous latency fluctuates within [-jitter, +jitter]
      const jitterNoise = (Math.random() * 2 - 1) * currentJitterMs;
      const instantLatency = Math.max(4, Math.round(currentLatencyMs + jitterNoise));
      setLiveLatency(instantLatency);

      // Instantaneous Jitter RFC 3550 deviation
      const instantJitter = Math.max(1, Math.round(currentJitterMs + (Math.random() * 4 - 2)));
      setLiveJitter(instantJitter);

      // 2. Bandwidth noise: small multipath fading ±4%
      const bwFadingRatio = 1 + (Math.random() * 0.08 - 0.04);
      const instantBw = isBlackoutActive 
        ? 50 
        : Math.max(100, Math.round(currentBandwidthKbps * bwFadingRatio));
      setLiveBandwidth(instantBw);

      // 3. Packet loss dynamic simulation
      const instantLoss = isBlackoutActive 
        ? 100 
        : currentPacketLossPct;
      setLivePacketLoss(instantLoss);

      // Generate packet arrival
      const isDropped = Math.random() * 100 < instantLoss;
      setPacketStream(prev => {
        const next = [...prev.slice(1), !isDropped];
        return next;
      });
      setPacketsSent(prev => prev + 1);
      if (isDropped) setPacketsLost(prev => prev + 1);

      // Add to rolling history for live oscilloscope canvas
      historyRef.current.push({
        bw: instantBw,
        latency: instantLatency,
        jitter: instantJitter,
        lost: isDropped
      });
      if (historyRef.current.length > 50) historyRef.current.shift();

      // Draw oscilloscope
      drawOscilloscope();
    }, 350);

    return () => clearInterval(interval);
  }, [currentBandwidthKbps, currentLatencyMs, currentPacketLossPct, currentJitterMs, isBlackoutActive]);

  // Oscilloscope Canvas Rendering Function
  const drawOscilloscope = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    const width = canvas.width;
    const height = canvas.height;

    // Clear background
    ctx.fillStyle = '#070a13';
    ctx.fillRect(0, 0, width, height);

    // Grid lines
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.05)';
    ctx.lineWidth = 1;
    for (let x = 0; x < width; x += 40) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
    for (let y = 0; y < height; y += height / 4) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }

    const history = historyRef.current;
    if (history.length < 2) return;

    const count = history.length;
    const stepX = width / (50 - 1);

    // Trace 1: Latency & Jitter Envelope (Amber/Orange)
    // Scale: 0 to 400ms
    const maxLatScale = 400;
    ctx.beginPath();
    history.forEach((pt, idx) => {
      const x = idx * stepX;
      const y = height - (Math.min(maxLatScale, pt.latency) / maxLatScale) * (height - 10);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#ffb703';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(255, 183, 3, 0.4)';
    ctx.shadowBlur = 6;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Trace 2: Bandwidth Waveform (Cyan)
    // Scale: 0 to 40,000 kbps
    const maxBwScale = 40000;
    ctx.beginPath();
    history.forEach((pt, idx) => {
      const x = idx * stepX;
      const y = height - (Math.min(maxBwScale, pt.bw) / maxBwScale) * (height - 10);
      if (idx === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    });
    ctx.strokeStyle = '#00f2fe';
    ctx.lineWidth = 2;
    ctx.shadowColor = 'rgba(0, 242, 254, 0.4)';
    ctx.shadowBlur = 6;
    ctx.stroke();
    ctx.shadowBlur = 0;

    // Draw Packet Loss Spike Drops (Red markers)
    history.forEach((pt, idx) => {
      if (pt.lost) {
        const x = idx * stepX;
        ctx.fillStyle = '#ff4d6d';
        ctx.beginPath();
        ctx.arc(x, 10, 3.5, 0, Math.PI * 2);
        ctx.fill();
      }
    });
  };

  // Effective Bandwidth after packet loss reduction
  const effectiveThroughputBps = (liveBandwidth * 1000) * (1 - (livePacketLoss / 100));
  const channelUtilizationPct = Math.min(100, Math.round((activeVideoBitrate / (liveBandwidth * 1000 || 1)) * 100));

  // Latency rating
  const latencyStatus = liveLatency < 35 
    ? { label: 'Ultra-Low (5G mmWave)', color: 'var(--accent-emerald)' }
    : liveLatency < 100 
    ? { label: 'Optimal (4G LTE)', color: 'var(--accent-cyan)' }
    : liveLatency < 250 
    ? { label: 'Moderate (Subway Transit)', color: 'var(--accent-amber)' }
    : { label: 'High Congestion / Lag', color: 'var(--accent-rose)' };

  // Packet Loss Health Score
  const packetLossStatus = livePacketLoss === 0 
    ? { label: '100% Reliable (0 Loss)', color: 'var(--accent-emerald)' }
    : livePacketLoss <= 3.0 
    ? { label: 'Good (< 3% Loss)', color: 'var(--accent-cyan)' }
    : livePacketLoss <= 8.0 
    ? { label: 'Degraded Channel', color: 'var(--accent-amber)' }
    : { label: 'Critical Drop Rate', color: 'var(--accent-rose)' };

  // Jitter Buffer Rating
  const jitterStatus = liveJitter < 15
    ? { label: 'Smooth Buffer Playout', color: 'var(--accent-emerald)' }
    : liveJitter < 60
    ? { label: 'Mild Delay Variance', color: 'var(--accent-amber)' }
    : { label: 'Severe Jitter Spike', color: 'var(--accent-rose)' };

  // Content JSX for both Modal and Embedded View
  const content = (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Top Header / Status Strip */}
      <div style={{ 
        display: 'flex', 
        alignItems: 'center', 
        justifyContent: 'space-between', 
        borderBottom: '1px solid var(--border-subtle)', 
        paddingBottom: '0.85rem',
        flexWrap: 'wrap',
        gap: '0.5rem'
      }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.65rem' }}>
          <div style={{ 
            width: '38px', 
            height: '38px', 
            borderRadius: '10px', 
            background: 'rgba(0, 242, 254, 0.15)', 
            display: 'flex', 
            alignItems: 'center', 
            justifyContent: 'center' 
          }}>
            <Activity size={20} color="var(--accent-cyan)" />
          </div>
          <div>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <h3 style={{ fontSize: '1.15rem', fontWeight: 800, margin: 0 }}>
                Live Network & Wireless Channel Monitor
              </h3>
              <span className="pulse-dot online" title="Telemetry Active" />
              <span className="badge badge-cyan" style={{ fontSize: '0.65rem', padding: '0.15rem 0.5rem' }}>
                LIVE 60Hz
              </span>
            </div>
            <p style={{ fontSize: '0.75rem', color: '#94a3b8', margin: 0 }}>
              Active Channel: <strong style={{ color: '#fff' }}>{currentScenarioName}</strong> ({networkType.toUpperCase()})
            </p>
          </div>
        </div>

        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {isBlackoutActive && (
            <span className="badge badge-rose" style={{ animation: 'pulse-ring 1s infinite' }}>
              <ShieldAlert size={12} /> BLACKOUT DETECTED
            </span>
          )}
          {!isEmbedded && onClose && (
            <button onClick={onClose} className="btn btn-secondary btn-sm" style={{ padding: '0.35rem' }}>
              <X size={18} />
            </button>
          )}
        </div>
      </div>

      {/* 4 PRIMARY METRIC CARDS: BANDWIDTH | LATENCY | PACKET LOSS | JITTER */}
      <div style={{ 
        display: 'grid', 
        gridTemplateColumns: 'repeat(auto-fit, minmax(210px, 1fr))', 
        gap: '0.85rem' 
      }}>
        {/* 1. BANDWIDTH CARD */}
        <div className="glass-panel" style={{ 
          padding: '1rem', 
          border: '1px solid rgba(0, 242, 254, 0.25)', 
          background: 'rgba(15, 23, 42, 0.7)' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>
              Download Bandwidth
            </span>
            <Gauge size={16} color="var(--accent-cyan)" />
          </div>
          <div className="mono" style={{ fontSize: '1.65rem', fontWeight: 800, color: 'var(--accent-cyan)', lineHeight: 1.1 }}>
            {liveBandwidth >= 1000 ? `${(liveBandwidth / 1000).toFixed(2)}` : liveBandwidth}
            <span style={{ fontSize: '0.85rem', color: '#94a3b8', marginLeft: '4px' }}>
              {liveBandwidth >= 1000 ? 'Mbps' : 'kbps'}
            </span>
          </div>
          <div style={{ fontSize: '0.68rem', color: '#94a3b8', marginTop: '0.4rem' }}>
            Effective: <strong style={{ color: '#e2e8f0' }}>{(effectiveThroughputBps / 1000000).toFixed(2)} Mbps</strong>
          </div>
          {/* Channel Utilization Bar */}
          <div style={{ marginTop: '0.5rem' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.65rem', color: '#64748b', marginBottom: '2px' }}>
              <span>Video Link Load</span>
              <span className="mono">{channelUtilizationPct}%</span>
            </div>
            <div style={{ width: '100%', height: '4px', background: 'rgba(255, 255, 255, 0.1)', borderRadius: '2px', overflow: 'hidden' }}>
              <div style={{ 
                width: `${channelUtilizationPct}%`, 
                height: '100%', 
                background: channelUtilizationPct > 80 ? 'var(--grad-amber)' : 'var(--grad-cyan-blue)' 
              }} />
            </div>
          </div>
        </div>

        {/* 2. LATENCY (RTT) CARD */}
        <div className="glass-panel" style={{ 
          padding: '1rem', 
          border: '1px solid rgba(255, 183, 3, 0.25)', 
          background: 'rgba(15, 23, 42, 0.7)' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>
              Round-Trip Latency (RTT)
            </span>
            <Clock size={16} color="var(--accent-amber)" />
          </div>
          <div className="mono" style={{ fontSize: '1.65rem', fontWeight: 800, color: latencyStatus.color, lineHeight: 1.1 }}>
            {liveLatency}
            <span style={{ fontSize: '0.85rem', color: '#94a3b8', marginLeft: '4px' }}>ms</span>
          </div>
          <div style={{ fontSize: '0.68rem', color: latencyStatus.color, marginTop: '0.4rem', fontWeight: 600 }}>
            {latencyStatus.label}
          </div>
          <div style={{ fontSize: '0.65rem', color: '#64748b', marginTop: '0.4rem' }}>
            Nominal RTT: {currentLatencyMs}ms (Base)
          </div>
        </div>

        {/* 3. PACKET LOSS CARD */}
        <div className="glass-panel" style={{ 
          padding: '1rem', 
          border: '1px solid rgba(255, 77, 109, 0.25)', 
          background: 'rgba(15, 23, 42, 0.7)' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>
              Packet Loss Rate
            </span>
            <ShieldAlert size={16} color="var(--accent-rose)" />
          </div>
          <div className="mono" style={{ fontSize: '1.65rem', fontWeight: 800, color: packetLossStatus.color, lineHeight: 1.1 }}>
            {livePacketLoss.toFixed(1)}
            <span style={{ fontSize: '0.85rem', color: '#94a3b8', marginLeft: '4px' }}>%</span>
          </div>
          <div style={{ fontSize: '0.68rem', color: packetLossStatus.color, marginTop: '0.4rem', fontWeight: 600 }}>
            {packetLossStatus.label}
          </div>
          <div style={{ fontSize: '0.65rem', color: '#64748b', marginTop: '0.4rem' }}>
            Dropped: {packetsLost} / {packetsSent} packets
          </div>
        </div>

        {/* 4. JITTER CARD */}
        <div className="glass-panel" style={{ 
          padding: '1rem', 
          border: '1px solid rgba(168, 85, 247, 0.25)', 
          background: 'rgba(15, 23, 42, 0.7)' 
        }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.35rem' }}>
            <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 700, textTransform: 'uppercase' }}>
              Jitter (Delay Variance)
            </span>
            <Zap size={16} color="var(--accent-violet)" />
          </div>
          <div className="mono" style={{ fontSize: '1.65rem', fontWeight: 800, color: jitterStatus.color, lineHeight: 1.1 }}>
            ±{liveJitter}
            <span style={{ fontSize: '0.85rem', color: '#94a3b8', marginLeft: '4px' }}>ms</span>
          </div>
          <div style={{ fontSize: '0.68rem', color: jitterStatus.color, marginTop: '0.4rem', fontWeight: 600 }}>
            {jitterStatus.label}
          </div>
          <div style={{ fontSize: '0.65rem', color: '#64748b', marginTop: '0.4rem' }}>
            RFC 3550 Inter-Arrival Spec
          </div>
        </div>
      </div>

      {/* REAL-TIME DYNAMIC OSCILLOSCOPE CANVAS */}
      <div className="glass-panel" style={{ padding: '1rem', background: 'rgba(8, 12, 22, 0.8)' }}>
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.65rem' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <Activity size={16} color="var(--accent-cyan)" />
            <span style={{ fontSize: '0.8rem', fontWeight: 700 }}>
              Live Wireless Oscilloscope (Multi-Trace Waveform)
            </span>
          </div>
          {/* Legend */}
          <div style={{ display: 'flex', alignItems: 'center', gap: '1rem', fontSize: '0.7rem' }}>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--accent-cyan)' }}>
              <span style={{ width: '10px', height: '2px', background: 'var(--accent-cyan)' }} /> Bandwidth (0-40M)
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--accent-amber)' }}>
              <span style={{ width: '10px', height: '2px', background: 'var(--accent-amber)' }} /> Latency & Jitter (0-400ms)
            </span>
            <span style={{ display: 'flex', alignItems: 'center', gap: '0.3rem', color: 'var(--accent-rose)' }}>
              <span style={{ width: '6px', height: '6px', borderRadius: '50%', background: 'var(--accent-rose)' }} /> Lost Packet
            </span>
          </div>
        </div>

        {/* Oscilloscope Canvas */}
        <canvas
          ref={canvasRef}
          width={720}
          height={140}
          style={{
            width: '100%',
            height: '140px',
            borderRadius: '8px',
            border: '1px solid rgba(255, 255, 255, 0.08)',
            display: 'block'
          }}
        />
      </div>

      {/* PACKET STREAM MATRIX & REAL BROWSER CONNECTION PROBE */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '0.85rem' }}>
        {/* Packet Stream Matrix */}
        <div className="glass-panel" style={{ padding: '0.9rem', background: 'rgba(12, 17, 30, 0.65)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
            <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#e2e8f0' }}>
              Live Packet Flow Matrix (Last 32 Packets):
            </span>
            <span className="mono" style={{ fontSize: '0.7rem', color: '#94a3b8' }}>
              Loss: {livePacketLoss.toFixed(1)}%
            </span>
          </div>

          {/* LED Blocks */}
          <div style={{ display: 'flex', gap: '4px', flexWrap: 'wrap' }}>
            {packetStream.map((received, i) => (
              <div
                key={i}
                style={{
                  width: '12px',
                  height: '12px',
                  borderRadius: '3px',
                  background: received ? 'var(--accent-emerald)' : 'var(--accent-rose)',
                  boxShadow: received 
                    ? '0 0 6px rgba(0, 230, 153, 0.4)' 
                    : '0 0 8px rgba(255, 77, 109, 0.7)',
                  transition: 'background 0.2s'
                }}
                title={received ? `Packet #${packetsSent - 32 + i}: Delivered` : `Packet #${packetsSent - 32 + i}: DROPPED`}
              />
            ))}
          </div>

          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: '0.65rem', color: '#64748b', marginTop: '0.5rem' }}>
            <span>■ Green: Delivered Packet</span>
            <span>■ Red: Dropped Packet (Retransmitted)</span>
          </div>
        </div>

        {/* Real Hardware Network Interface Probe */}
        <div className="glass-panel" style={{ padding: '0.9rem', background: 'rgba(12, 17, 30, 0.65)' }}>
          <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.4rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.35rem' }}>
              <Wifi size={14} color="var(--accent-cyan)" />
              <span style={{ fontSize: '0.75rem', fontWeight: 700, color: '#e2e8f0' }}>
                Hardware Interface Probe (Browser API)
              </span>
            </div>
            <button
              onClick={handleTestRealPing}
              disabled={isProbing}
              className="btn btn-secondary btn-sm"
              style={{ padding: '0.2rem 0.5rem', fontSize: '0.68rem' }}
            >
              <RefreshCw size={11} className={isProbing ? 'animate-spin' : ''} />
              <span>{isProbing ? 'Pinging...' : 'Ping Origin'}</span>
            </button>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem', fontSize: '0.72rem' }}>
            <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.4rem 0.6rem', borderRadius: '6px' }}>
              <span style={{ color: '#94a3b8' }}>Real Origin Ping: </span>
              <strong className="mono" style={{ color: 'var(--accent-cyan)' }}>
                {realProbePing !== null ? `${realProbePing} ms` : 'Click Ping'}
              </strong>
            </div>

            <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.4rem 0.6rem', borderRadius: '6px' }}>
              <span style={{ color: '#94a3b8' }}>Effective Type: </span>
              <strong className="mono" style={{ color: 'var(--accent-emerald)', textTransform: 'uppercase' }}>
                {browserNetworkInfo?.effectiveType || '4G/WIFI'}
              </strong>
            </div>

            <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.4rem 0.6rem', borderRadius: '6px' }}>
              <span style={{ color: '#94a3b8' }}>Browser Downlink: </span>
              <strong className="mono" style={{ color: '#fff' }}>
                {browserNetworkInfo?.downlink ? `${browserNetworkInfo.downlink} Mbps` : 'High-Speed'}
              </strong>
            </div>

            <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.4rem 0.6rem', borderRadius: '6px' }}>
              <span style={{ color: '#94a3b8' }}>Host Latency: </span>
              <strong className="mono" style={{ color: '#fff' }}>
                {browserNetworkInfo?.rtt ? `${browserNetworkInfo.rtt} ms` : '~20 ms'}
              </strong>
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  // If embedded in the main dashboard view:
  if (isEmbedded) {
    return (
      <div className="glass-panel" style={{ padding: '1.25rem' }}>
        {content}
      </div>
    );
  }

  // If rendered as a Modal Dialog:
  if (!isOpen) return null;

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ maxWidth: '860px' }}>
        {content}
      </div>
    </div>
  );
}
