import React from 'react';
import { 
  Award, 
  Zap, 
  Clock, 
  Repeat, 
  ShieldCheck 
} from 'lucide-react';

export default function QoEDashboard({
  qoeData,
  totalStallCount,
  totalStallDuration,
  switchCount,
  powerStats,
  droppedFrames,
  totalFrames,
  isLowBatteryMode
}) {
  const mos = qoeData?.mos || 4.5;
  const mosColor = mos >= 4.0 ? 'var(--accent-emerald)' : mos >= 3.2 ? 'var(--accent-amber)' : 'var(--accent-rose)';

  // Calculate estimated energy savings vs continuous unconstrained 1080p (which burns ~1750mW)
  const baselinePower1080p = 1750;
  const currentTotalPower = powerStats?.totalPowerMw || 850;
  const energySavingsPct = Math.max(0, Math.min(65, Math.round(((baselinePower1080p - currentTotalPower) / baselinePower1080p) * 100)));

  const frameDropRate = totalFrames > 0 ? (droppedFrames / totalFrames) * 100 : 0;

  return (
    <div className="glass-panel" style={{ padding: '1.25rem', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      {/* Header */}
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', borderBottom: '1px solid var(--border-subtle)', paddingBottom: '0.75rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          <Award size={18} color="var(--accent-cyan)" />
          <h3 style={{ fontSize: '1rem', fontWeight: 700, margin: 0 }}>
            QoE & Mobile Performance Optimization Telemetry
          </h3>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
          {isLowBatteryMode && (
            <span className="badge badge-amber">
              <Zap size={11} /> POWER SAVER CAP
            </span>
          )}
          <span className="badge badge-emerald">ITU-T P.1203 COMPLIANT</span>
        </div>
      </div>

      {/* Main Grid: QoE MOS Gauge + Metric Cards */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.25rem', alignItems: 'center' }}>
        {/* ITU-T P.1203 MOS Score Hero Box */}
        <div style={{
          background: 'rgba(5, 8, 16, 0.65)',
          border: `1px solid ${mosColor}`,
          borderRadius: '16px',
          padding: '1.25rem',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          boxShadow: `0 0 25px ${mosColor}33`,
          position: 'relative'
        }}>
          <div style={{ fontSize: '0.75rem', color: '#94a3b8', textTransform: 'uppercase', letterSpacing: '0.05em', fontWeight: 600 }}>
            Standardized QoE Score (MOS)
          </div>

          <div style={{
            fontSize: '3.2rem',
            fontFamily: 'var(--font-mono)',
            fontWeight: 800,
            color: mosColor,
            lineHeight: 1.1,
            margin: '0.5rem 0'
          }}>
            {mos.toFixed(2)}
            <span style={{ fontSize: '1.2rem', color: '#64748b' }}>/5.0</span>
          </div>

          <div className="badge" style={{
            background: `${mosColor}22`,
            color: mosColor,
            border: `1px solid ${mosColor}55`
          }}>
            {mos >= 4.2 ? '★ EXCELLENT (PERFECT MOBILITY)' : mos >= 3.4 ? '▲ GOOD (STABLE PLAYBACK)' : '▼ DEGRADED (STALL DETECTED)'}
          </div>

          {/* Sub components breakdown */}
          <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%', marginTop: '1rem', borderTop: '1px solid var(--border-subtle)', paddingTop: '0.75rem', fontSize: '0.7rem', color: '#94a3b8' }}>
            <span>Visual: <strong style={{ color: '#fff' }}>+{qoeData?.qualityScore || '3.5'}</strong></span>
            <span>Stall Penalty: <strong style={{ color: 'var(--accent-rose)' }}>-{qoeData?.stallPenalty || '0.0'}</strong></span>
            <span>Instability: <strong style={{ color: 'var(--accent-amber)' }}>-{qoeData?.switchPenalty || '0.0'}</strong></span>
          </div>
        </div>

        {/* 4 Metric Tiles Grid */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.75rem' }}>
          {/* Tile 1: Stall & Rebuffering */}
          <div className="data-pill">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Clock size={14} color="var(--accent-rose)" />
              <span className="data-pill-label">Stall Count / Time</span>
            </div>
            <div className="data-pill-value" style={{ color: totalStallDuration > 0 ? 'var(--accent-rose)' : '#fff' }}>
              {totalStallCount} <span style={{ fontSize: '0.85rem', fontWeight: 500, color: '#94a3b8' }}>({totalStallDuration.toFixed(1)}s)</span>
            </div>
            <span style={{ fontSize: '0.68rem', color: '#64748b' }}>
              Rebuffering Ratio: {qoeData?.stallRatioPct || '0.0'}%
            </span>
          </div>

          {/* Tile 2: Quality Switches */}
          <div className="data-pill">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Repeat size={14} color="var(--accent-violet)" />
              <span className="data-pill-label">Instability Switches</span>
            </div>
            <div className="data-pill-value" style={{ color: '#c084fc' }}>
              {switchCount}
            </div>
            <span style={{ fontSize: '0.68rem', color: '#64748b' }}>
              Anti-Oscillation: Active
            </span>
          </div>

          {/* Tile 3: Battery Energy Savings */}
          <div className="data-pill">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <Zap size={14} color="var(--accent-emerald)" />
              <span className="data-pill-label">Energy Optimization</span>
            </div>
            <div className="data-pill-value" style={{ color: 'var(--accent-emerald)' }}>
              +{energySavingsPct}%
            </div>
            <span style={{ fontSize: '0.68rem', color: '#64748b' }}>
              Draw: ~{currentTotalPower} mW
            </span>
          </div>

          {/* Tile 4: Hardware Decoder Drop */}
          <div className="data-pill">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              <ShieldCheck size={14} color="var(--accent-cyan)" />
              <span className="data-pill-label">Decoder Frames</span>
            </div>
            <div className="data-pill-value" style={{ color: frameDropRate > 5 ? 'var(--accent-amber)' : '#38bdf8' }}>
              {frameDropRate.toFixed(1)}%
            </div>
            <span style={{ fontSize: '0.68rem', color: '#64748b' }}>
              {droppedFrames} drops / {totalFrames}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
