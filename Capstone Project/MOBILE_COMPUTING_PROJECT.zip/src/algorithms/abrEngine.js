/**
 * MediaFlow – Adaptive Bitrate (ABR) Engine & Mobile Optimization
 * Mobile Computing Capstone Research Algorithms
 */

// Available streaming quality ladder (standard multi-bitrate ladder)
export const DEFAULT_BITRATE_LADDER = [
  { level: 0, resolution: '240p', width: 426, height: 240, bitrate: 400000, fps: 24, label: '240p (Mobile Ultra-Low)' },
  { level: 1, resolution: '360p', width: 640, height: 360, bitrate: 800000, fps: 30, label: '360p (Mobile Cellular 3G)' },
  { level: 2, resolution: '480p', width: 854, height: 480, bitrate: 1400000, fps: 30, label: '480p (Standard 4G)' },
  { level: 3, resolution: '720p', width: 1280, height: 720, bitrate: 2800000, fps: 30, label: '720p HD (Power-Saver Cap)' },
  { level: 4, resolution: '1080p', width: 1920, height: 1080, bitrate: 5000000, fps: 60, label: '1080p FHD (High-Speed 5G/WiFi)' }
];

// Verified high-performance multi-bitrate HLS streams
export const SAMPLE_STREAMS = [
  {
    name: 'Big Buck Bunny (Multi-Bitrate)',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    genre: 'Animation HD (5 Levels)',
    duration: '09:56'
  },
  {
    name: 'Apple BipBop Advanced fMP4',
    url: 'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8',
    genre: 'Adaptive Test Patterns',
    duration: '10:00'
  },
  {
    name: 'Tears of Steel (4K/HD Stream)',
    url: 'https://demo.unified-streaming.com/k8s/features/stable/video/tears-of-steel/tears-of-steel.ism/.m3u8',
    genre: 'Sci-Fi Action (Multi-Bitrate)',
    duration: '12:14'
  }
];

// Presets for real-world mobile network simulation
export const MOBILE_SCENARIOS = {
  STABLE_5G: {
    id: 'STABLE_5G',
    name: '5G mmWave Ultra-Fast',
    description: 'High bandwidth, ultra-low latency mobile cell tower',
    bandwidthKbps: 35000,
    latencyMs: 18,
    jitterMs: 4,
    packetLossPct: 0,
    signalStrengthPct: 98,
    networkType: '5g'
  },
  HIGHWAY_HANDOVER: {
    id: 'HIGHWAY_HANDOVER',
    name: 'Highway 4G/5G Handover',
    description: 'Mobility velocity 100km/h with cell tower handoffs and dips',
    bandwidthKbps: 4500,
    latencyMs: 85,
    jitterMs: 45,
    packetLossPct: 2.5,
    signalStrengthPct: 65,
    networkType: '4g'
  },
  SUBWAY_COMMUTE: {
    id: 'SUBWAY_COMMUTE',
    name: 'Subway / Tunnel Transit',
    description: 'Severe multi-path fading, periodic 0 kbps dead-zones',
    bandwidthKbps: 1100,
    latencyMs: 240,
    jitterMs: 110,
    packetLossPct: 8.0,
    signalStrengthPct: 28,
    networkType: '3g'
  },
  STADIUM_CONGESTION: {
    id: 'STADIUM_CONGESTION',
    name: 'Crowded Stadium / Congestion',
    description: 'Heavy base-station resource contention and high queue delay',
    bandwidthKbps: 750,
    latencyMs: 380,
    jitterMs: 140,
    packetLossPct: 12.0,
    signalStrengthPct: 45,
    networkType: '3g'
  },
  BATTERY_CRITICAL: {
    id: 'BATTERY_CRITICAL',
    name: 'Low Battery (< 15%)',
    description: 'Hardware thermal limit, energy conservation mode activated',
    bandwidthKbps: 12000,
    latencyMs: 35,
    jitterMs: 10,
    packetLossPct: 0.5,
    signalStrengthPct: 88,
    forceBatteryLow: true,
    networkType: '4g'
  }
};

/**
 * Throughput-Based EWMA Adaptation (Traditional Heuristic)
 */
export function calculateThroughputEWMA(estimatedThroughputBps, bitrateLadder, safetyFactor = 0.8) {
  const safeThroughput = estimatedThroughputBps * safetyFactor;
  let chosen = bitrateLadder[0];
  for (let i = 0; i < bitrateLadder.length; i++) {
    if (bitrateLadder[i].bitrate <= safeThroughput) {
      chosen = bitrateLadder[i];
    }
  }
  return {
    level: chosen.level,
    reason: `EWMA Throughput: ${(estimatedThroughputBps / 1000000).toFixed(2)} Mbps (Safety: ${(safeThroughput / 1000000).toFixed(2)} Mbps)`
  };
}

/**
 * BBA (Buffer-Based Adaptation - Huang et al.)
 * Reservoir Zone: < 4s (force lowest quality)
 * Cushion Zone: 4s to 18s (proportional scaling)
 * Safe Zone: > 18s (highest quality)
 */
export function calculateBBA(bufferSeconds, bitrateLadder, reservoir = 4.0, cushion = 14.0) {
  const maxBuffer = reservoir + cushion;
  const n = bitrateLadder.length;

  if (bufferSeconds <= reservoir) {
    return {
      level: 0,
      reason: `BBA Reservoir Alert: Buffer ${bufferSeconds.toFixed(1)}s <= ${reservoir}s (Emergency Floor)`
    };
  }

  if (bufferSeconds >= maxBuffer) {
    return {
      level: n - 1,
      reason: `BBA Safe Zone: Buffer ${bufferSeconds.toFixed(1)}s >= ${maxBuffer}s (Peak Quality)`
    };
  }

  // Cushion linear interpolation
  const ratio = (bufferSeconds - reservoir) / cushion;
  const targetLevel = Math.min(n - 1, Math.max(0, Math.floor(ratio * n)));

  return {
    level: targetLevel,
    reason: `BBA Cushion Ratio: ${(ratio * 100).toFixed(0)}% (Buffer: ${bufferSeconds.toFixed(1)}s)`
  };
}

/**
 * MediaFlow Hybrid Mobile-Aware Optimizer (Core Research Algorithm)
 * Integrates:
 * 1. Network Throughput EWMA
 * 2. Buffer Health + Derivative (dB/dt)
 * 3. Mobile Battery State & Thermal Throttle
 * 4. Hardware Decoder Frame Drop Percentage
 * 5. Switching Hysteresis (Anti-Oscillation)
 */
export function calculateMediaFlowHybrid({
  bufferSeconds,
  bufferDelta, // dB/dt
  estimatedThroughputBps,
  bitrateLadder,
  currentLevel,
  batteryLevelPct,
  isBatteryCharging,
  droppedFramesRate, // frames dropped / total
  timeSinceLastSwitchSec
}) {
  let targetLevel = 0;
  const reasons = [];

  // Step 1: Base Candidate from BBA + EWMA consensus
  const bbaResult = calculateBBA(bufferSeconds, bitrateLadder, 4.5, 12.0);
  const ewmaResult = calculateThroughputEWMA(estimatedThroughputBps, bitrateLadder, 0.85);

  // Take the safer minimum of BBA and Throughput to avoid buffer drain
  targetLevel = Math.min(bbaResult.level, ewmaResult.level);
  reasons.push(`Consensus: BBA[${bbaResult.level}] & EWMA[${ewmaResult.level}] -> ${targetLevel}`);

  // Step 2: Predictive Buffer Drainage Check (dB/dt)
  if (bufferDelta < -0.6 && bufferSeconds < 7.0 && targetLevel > 0) {
    targetLevel = Math.max(0, targetLevel - 1);
    reasons.push(`Predictive Drop: Buffer draining at ${bufferDelta.toFixed(2)}s/s`);
  }

  // Step 3: Mobile Energy & Battery Awareness
  if (!isBatteryCharging && batteryLevelPct !== null) {
    if (batteryLevelPct <= 15) {
      // Emergency Battery Saver: Cap at 480p (index 2) to reduce GPU/decoding compute
      if (targetLevel > 2) {
        targetLevel = 2;
        reasons.push(`Battery Critical (${batteryLevelPct}%): Down-capped to 480p for energy preservation`);
      }
    } else if (batteryLevelPct <= 25) {
      // Normal Power-Saver Cap: 720p (index 3)
      if (targetLevel > 3) {
        targetLevel = 3;
        reasons.push(`Battery Low (${batteryLevelPct}%): Capped to 720p HD to reduce drain`);
      }
    }
  }

  // Step 4: Hardware Decoder Stress / Frame Drop Check
  if (droppedFramesRate > 0.05 && targetLevel > 1) {
    targetLevel = Math.max(1, targetLevel - 1);
    reasons.push(`Hardware Stress: Frame drop rate ${(droppedFramesRate * 100).toFixed(1)}% > 5% threshold`);
  }

  // Step 5: Anti-Oscillation Hysteresis (Smooth QoE)
  // If stepping up, require at least 5 seconds dwell time in current quality
  if (targetLevel > currentLevel) {
    if (timeSinceLastSwitchSec < 5.0) {
      targetLevel = currentLevel;
      reasons.push(`Anti-Oscillation: Suppressed quality oscillation (${timeSinceLastSwitchSec.toFixed(1)}s < 5s dwell)`);
    }
  }

  return {
    level: targetLevel,
    reasons: reasons,
    primaryReason: reasons[reasons.length - 1]
  };
}

/**
 * Standard ITU-T P.1203 Quality of Experience (QoE) Formulator
 * Computes perceived MOS score (1.0 to 5.0) based on:
 * - Average Bitrate / Visual Quality
 * - Rebuffering Stall Penalties (heavily penalizes stalls)
 * - Quality Switch Instability Penalties
 */
export function calculateQoEScore({
  averageBitrateBps,
  totalStallDurationSec,
  totalPlaybackDurationSec,
  switchCount,
  bitrateLadder
}) {
  if (totalPlaybackDurationSec <= 0) return 4.5;

  const minBitrate = bitrateLadder[0].bitrate;
  const maxBitrate = bitrateLadder[bitrateLadder.length - 1].bitrate;

  // 1. Visual Quality component (Logarithmic utility): Scale 1.0 - 5.0
  const normalizedBitrate = Math.min(1.0, Math.max(0.0, (averageBitrateBps - minBitrate) / (maxBitrate - minBitrate)));
  const qoeQuality = 2.0 + (normalizedBitrate * 2.8);

  // 2. Rebuffering Stall Ratio Penalty
  const stallRatio = totalStallDurationSec / (totalPlaybackDurationSec + totalStallDurationSec);
  // ITU-T P.1203 applies exponential penalty on stall ratio
  const stallPenalty = Math.min(3.2, stallRatio * 18.0 + (totalStallDurationSec > 0 ? 0.4 : 0));

  // 3. Switching Instability Penalty
  const switchRate = switchCount / (totalPlaybackDurationSec / 60 || 1); // switches per min
  const switchPenalty = Math.min(0.8, switchRate * 0.12);

  // Final MOS formulation clamped between 1.0 and 5.0
  const finalMOS = Math.max(1.0, Math.min(5.0, qoeQuality - stallPenalty - switchPenalty));

  return {
    mos: parseFloat(finalMOS.toFixed(2)),
    qualityScore: parseFloat(qoeQuality.toFixed(2)),
    stallPenalty: parseFloat(stallPenalty.toFixed(2)),
    switchPenalty: parseFloat(switchPenalty.toFixed(2)),
    stallRatioPct: parseFloat((stallRatio * 100).toFixed(1))
  };
}

/**
 * Estimated Battery Energy Consumption Model (Mobile GPU + WiFi/Cellular Radio)
 * Base energy: 350mW (Screen + Audio + Base CPU)
 * Decoding energy: Scaled by bitrate and resolution pixels
 * Radio energy: Proportional to throughput and network type
 */
export function calculateEstimatedPowerDrain({ resolution, networkType, isStalled }) {
  let basePower = 400; // mW
  let decoderPower = 200; // mW

  switch (resolution) {
    case '1080p': decoderPower = 950; break;
    case '720p': decoderPower = 550; break;
    case '480p': decoderPower = 320; break;
    case '360p': decoderPower = 210; break;
    case '240p': decoderPower = 140; break;
    default: decoderPower = 400;
  }

  let radioPower = 300; // mW
  if (networkType === '5g') radioPower = 850;
  else if (networkType === '4g') radioPower = 520;
  else if (networkType === '3g') radioPower = 680; // High transmit retry power

  if (isStalled) {
    decoderPower = 50; // Idle while rebuffering
    radioPower = 900; // Searching for segments aggressively
  }

  const totalMilliwatts = basePower + decoderPower + radioPower;
  return {
    totalPowerMw: totalMilliwatts,
    decoderPowerMw: decoderPower,
    radioPowerMw: radioPower,
    basePowerMw: basePower
  };
}
