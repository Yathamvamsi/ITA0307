import React, { useState, useEffect, useRef, useCallback } from 'react';
import Navbar from './components/Navbar';
import VideoPlayer from './components/VideoPlayer';
import NetworkSimulator from './components/NetworkSimulator';
import TelemetryCharts from './components/TelemetryCharts';
import QoEDashboard from './components/QoEDashboard';
import BenchmarkModal from './components/BenchmarkModal';
import ArchitectureExplainerModal from './components/ArchitectureExplainerModal';
import LiveNetworkMonitor from './components/LiveNetworkMonitor';
import { 
  Play, 
  Film, 
  Activity, 
  Radio, 
  TrendingUp, 
  Sliders, 
  Cpu, 
  Wifi, 
  Battery, 
  BatteryCharging, 
  GitCompare, 
  BookOpen, 
  Sparkles, 
  Car, 
  TrainFront, 
  BatteryLow, 
  ShieldAlert,
  Layers,
  Award,
  Zap,
  Monitor,
  Smartphone
} from 'lucide-react';
import { 
  DEFAULT_BITRATE_LADDER, 
  SAMPLE_STREAMS,
  MOBILE_SCENARIOS, 
  calculateMediaFlowHybrid, 
  calculateBBA, 
  calculateThroughputEWMA, 
  calculateQoEScore, 
  calculateEstimatedPowerDrain 
} from './algorithms/abrEngine';

export default function App() {
  // Navigation & View Mode
  const [viewMode, setViewMode] = useState('mobile'); // 'mobile' | 'desktop'
  const [activeMobileTab, setActiveMobileTab] = useState('stream'); // 'stream' | 'network' | 'mobility' | 'telemetry' | 'more'
  const [isBenchmarkOpen, setIsBenchmarkOpen] = useState(false);
  const [isExplainerOpen, setIsExplainerOpen] = useState(false);
  const [isNetworkMonitorOpen, setIsNetworkMonitorOpen] = useState(false);

  // Screen & Device Detection
  const [isMobileScreen, setIsMobileScreen] = useState(() => {
    if (typeof window !== 'undefined') {
      return window.innerWidth <= 840 || Boolean(window.Capacitor && window.Capacitor.isNativePlatform?.());
    }
    return false;
  });

  useEffect(() => {
    const handleResize = () => {
      const isMobile = window.innerWidth <= 840 || Boolean(window.Capacitor && window.Capacitor.isNativePlatform?.());
      setIsMobileScreen(isMobile);
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Streaming Configuration
  const [selectedStreamUrl, setSelectedStreamUrl] = useState(SAMPLE_STREAMS[0].url);
  const [bitrateLadder, setBitrateLadder] = useState(DEFAULT_BITRATE_LADDER);
  const [currentLevelIndex, setCurrentLevelIndex] = useState(1);
  const [selectedAlgorithm, setSelectedAlgorithm] = useState('MEDIAFLOW_HYBRID'); // MEDIAFLOW_HYBRID | BBA | THROUGHPUT_EWMA | NAIVE_STATIC
  const [algorithmDecisionReason, setAlgorithmDecisionReason] = useState('Initialized MediaFlow Context-Aware Engine');

  // Network Channel Simulation
  const [currentScenario, setCurrentScenario] = useState(MOBILE_SCENARIOS.STABLE_5G);
  const [simulatedBandwidthKbps, setSimulatedBandwidthKbps] = useState(MOBILE_SCENARIOS.STABLE_5G.bandwidthKbps);
  const [simulatedLatencyMs, setSimulatedLatencyMs] = useState(MOBILE_SCENARIOS.STABLE_5G.latencyMs);
  const [simulatedPacketLossPct, setSimulatedPacketLossPct] = useState(MOBILE_SCENARIOS.STABLE_5G.packetLossPct);
  const [simulatedJitterMs, setSimulatedJitterMs] = useState(MOBILE_SCENARIOS.STABLE_5G.jitterMs);
  const [isBlackoutActive, setIsBlackoutActive] = useState(false);

  // Mobile Device State (Battery & Network)
  const [batteryLevel, setBatteryLevel] = useState(85);
  const [isCharging, setIsCharging] = useState(false);
  const [networkType, setNetworkType] = useState('5g');

  // Live Telemetry & Metrics
  const [bufferSeconds, setBufferSeconds] = useState(0);
  const [bufferDelta, setBufferDelta] = useState(0);
  const lastBufferRef = useRef(0);
  const wasStalledRef = useRef(false);
  const [totalStallCount, setTotalStallCount] = useState(0);
  const [totalStallDuration, setTotalStallDuration] = useState(0);
  const [switchCount, setSwitchCount] = useState(0);
  const lastSwitchTimeRef = useRef(0);
  const [droppedFrames, setDroppedFrames] = useState(0);
  const [totalFrames, setTotalFrames] = useState(100);
  const [playbackDuration, setPlaybackDuration] = useState(1);

  // Initialize switch time ref on mount
  useEffect(() => {
    lastSwitchTimeRef.current = Date.now();
  }, []);

  // Rolling Chart History (max 35 items)
  const [telemetryHistory, setTelemetryHistory] = useState([
    { time: 0, buffer: 2, bitrate: 800000, throughput: 35000000, level: 1 }
  ]);

  // QoE and Power Metrics
  const [qoeData, setQoeData] = useState({ mos: 4.5, qualityScore: 3.5, stallPenalty: 0, switchPenalty: 0, stallRatioPct: 0 });
  const [powerStats, setPowerStats] = useState({ totalPowerMw: 850, decoderPowerMw: 320, radioPowerMw: 300, basePowerMw: 400 });

  // Detect real browser battery if available
  useEffect(() => {
    if (navigator.getBattery) {
      navigator.getBattery().then((battery) => {
        setBatteryLevel(Math.round(battery.level * 100));
        setIsCharging(battery.charging);
        battery.addEventListener('levelchange', () => {
          setBatteryLevel(Math.round(battery.level * 100));
        });
        battery.addEventListener('chargingchange', () => {
          setIsCharging(battery.charging);
        });
      }).catch(() => {});
    }
  }, []);

  // Handle Scenario preset selection
  const handleSelectScenario = (scenario) => {
    setCurrentScenario(scenario);
    setSimulatedBandwidthKbps(scenario.bandwidthKbps);
    setSimulatedLatencyMs(scenario.latencyMs);
    setSimulatedPacketLossPct(scenario.packetLossPct);
    setSimulatedJitterMs(scenario.jitterMs);
    setNetworkType(scenario.networkType);

    if (scenario.forceBatteryLow) {
      setBatteryLevel(12);
      setIsCharging(false);
    }
  };

  // Trigger temporary blackout tunnel (4 seconds drop to 0 kbps)
  const handleTriggerBlackout = () => {
    setIsBlackoutActive(true);
    const prevBw = simulatedBandwidthKbps;
    setSimulatedBandwidthKbps(50); // drop to near zero

    setTimeout(() => {
      setSimulatedBandwidthKbps(prevBw);
      setIsBlackoutActive(false);
    }, 4000);
  };

  // Telemetry updates from VideoPlayer
  const handleTelemetryUpdate = useCallback((data) => {
    setBufferSeconds(data.bufferSeconds);
    const dBuffer = data.bufferSeconds - lastBufferRef.current;
    setBufferDelta(dBuffer);
    lastBufferRef.current = data.bufferSeconds;

    setDroppedFrames(data.droppedFrames);
    setTotalFrames(data.totalFrames);
    setPlaybackDuration((prev) => prev + 0.4);

    if (data.isStalled) {
      setTotalStallDuration((prev) => prev + 0.4);
      if (!wasStalledRef.current) {
        setTotalStallCount((prev) => prev + 1);
      }
    }
    wasStalledRef.current = data.isStalled;
  }, []);

  // Set available levels from HLS manifest
  const handleQualityLevelAssigned = useCallback((levels, defaultIdx) => {
    setBitrateLadder(levels);
    setCurrentLevelIndex(defaultIdx);
  }, []);

  // Core Adaptation Loop (Runs every 1.2 seconds)
  useEffect(() => {
    const adaptationTimer = setInterval(() => {
      const throughputBps = (simulatedBandwidthKbps * 1000) * (1 - (simulatedPacketLossPct / 100));
      const timeSinceLastSwitch = (Date.now() - lastSwitchTimeRef.current) / 1000;
      const frameDropRatio = totalFrames > 0 ? droppedFrames / totalFrames : 0;

      let target = currentLevelIndex;
      let decisionText = '';

      if (selectedAlgorithm === 'MEDIAFLOW_HYBRID') {
        const result = calculateMediaFlowHybrid({
          bufferSeconds,
          bufferDelta,
          estimatedThroughputBps: throughputBps,
          bitrateLadder,
          currentLevel: currentLevelIndex,
          batteryLevelPct: batteryLevel,
          isBatteryCharging: isCharging,
          droppedFramesRate: frameDropRatio,
          timeSinceLastSwitchSec: timeSinceLastSwitch
        });
        target = result.level;
        decisionText = result.primaryReason;
      } else if (selectedAlgorithm === 'BBA') {
        const result = calculateBBA(bufferSeconds, bitrateLadder, 4.0, 14.0);
        target = result.level;
        decisionText = result.reason;
      } else if (selectedAlgorithm === 'THROUGHPUT_EWMA') {
        const result = calculateThroughputEWMA(throughputBps, bitrateLadder, 0.85);
        target = result.level;
        decisionText = result.reason;
      } else if (selectedAlgorithm === 'NAIVE_STATIC') {
        target = bitrateLadder.length - 1; // Stay locked to highest quality
        decisionText = 'Naive Static: Locked to highest 1080p stream';
      }

      // Check if target quality changed
      if (target !== currentLevelIndex && target >= 0 && target < bitrateLadder.length) {
        setCurrentLevelIndex(target);
        setSwitchCount((prev) => prev + 1);
        lastSwitchTimeRef.current = Date.now();
      }

      setAlgorithmDecisionReason(decisionText);

      // Current bitrate
      const activeBitrate = bitrateLadder[target]?.bitrate || 800000;
      const activeResolution = bitrateLadder[target]?.resolution || '480p';

      // Update rolling telemetry history for charts
      setTelemetryHistory((prev) => {
        const next = [
          ...prev,
          {
            time: prev.length,
            buffer: bufferSeconds,
            bitrate: activeBitrate,
            throughput: throughputBps,
            level: target
          }
        ];
        if (next.length > 35) next.shift();
        return next;
      });

      // Calculate real-time ITU-T QoE MOS
      const qoe = calculateQoEScore({
        averageBitrateBps: activeBitrate,
        totalStallDurationSec: totalStallDuration,
        totalPlaybackDurationSec: playbackDuration,
        switchCount,
        bitrateLadder
      });
      setQoeData(qoe);

      // Calculate power consumption
      const power = calculateEstimatedPowerDrain({
        resolution: activeResolution,
        networkType,
        isStalled: bufferSeconds < 0.2
      });
      setPowerStats(power);
    }, 1200);

    return () => clearInterval(adaptationTimer);
  }, [
    selectedAlgorithm,
    bufferSeconds,
    bufferDelta,
    simulatedBandwidthKbps,
    simulatedPacketLossPct,
    currentLevelIndex,
    bitrateLadder,
    batteryLevel,
    isCharging,
    droppedFrames,
    totalFrames,
    totalStallDuration,
    playbackDuration,
    switchCount,
    networkType
  ]);

  const activeLevelObj = bitrateLadder[currentLevelIndex] || DEFAULT_BITRATE_LADDER[1];
  const isLowBatteryCap = !isCharging && batteryLevel !== null && batteryLevel <= 20;
  const isMobileLayout = isMobileScreen || viewMode === 'mobile';

  return (
    <div className="app-container" style={isMobileLayout ? { padding: 0 } : {}}>
      {/* If Desktop View: Render Desktop Navbar */}
      {!isMobileLayout && (
        <Navbar
          viewMode={viewMode}
          setViewMode={setViewMode}
          selectedAlgorithm={selectedAlgorithm}
          setSelectedAlgorithm={setSelectedAlgorithm}
          batteryLevel={batteryLevel}
          isCharging={isCharging}
          networkType={networkType}
          onOpenExplainer={() => setIsExplainerOpen(true)}
          onOpenBenchmark={() => setIsBenchmarkOpen(true)}
          onOpenNetworkMonitor={() => setIsNetworkMonitorOpen(true)}
          currentBandwidthKbps={simulatedBandwidthKbps}
          currentLatencyMs={simulatedLatencyMs}
        />
      )}

      {/* ========================================================
          1. NATIVE MOBILE APP VIEW (Optimized for Mobile/APK Usage)
          ======================================================== */}
      {isMobileLayout ? (
        <div style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh', width: '100%' }}>
          {/* Native Mobile App Header Bar */}
          <header className="mobile-app-header">
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <div style={{
                width: '32px',
                height: '32px',
                borderRadius: '8px',
                background: 'var(--grad-cyan-blue)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                boxShadow: 'var(--shadow-glow)'
              }}>
                <Play size={16} color="#070a13" fill="#070a13" style={{ marginLeft: '1px' }} />
              </div>
              <div>
                <span style={{ fontSize: '1.05rem', fontWeight: 800, fontFamily: 'var(--font-heading)' }}>
                  Media<span className="gradient-text">Flow</span>
                </span>
              </div>
            </div>

            <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
              {/* Quick Algorithm Switcher Pill */}
              <button
                onClick={() => {
                  const algos = ['MEDIAFLOW_HYBRID', 'BBA', 'THROUGHPUT_EWMA', 'NAIVE_STATIC'];
                  const nextIdx = (algos.indexOf(selectedAlgorithm) + 1) % algos.length;
                  setSelectedAlgorithm(algos[nextIdx]);
                }}
                className="badge badge-cyan"
                style={{ cursor: 'pointer', padding: '0.25rem 0.55rem', fontSize: '0.68rem', gap: '0.25rem' }}
                title="Tap to cycle algorithm"
              >
                <Cpu size={12} />
                <span>{selectedAlgorithm === 'MEDIAFLOW_HYBRID' ? 'Hybrid' : selectedAlgorithm === 'THROUGHPUT_EWMA' ? 'EWMA' : selectedAlgorithm}</span>
              </button>

              {/* Status Indicator Chips */}
              <div className="glass-panel" style={{ display: 'flex', alignItems: 'center', gap: '0.35rem', padding: '0.25rem 0.5rem', borderRadius: '8px' }}>
                <Wifi size={12} color="var(--accent-cyan)" />
                <span className="mono" style={{ fontSize: '0.68rem', color: 'var(--accent-cyan)', fontWeight: 700, textTransform: 'uppercase' }}>
                  {networkType}
                </span>
                <span style={{ color: 'var(--border-subtle)', fontSize: '0.65rem' }}>|</span>
                {isCharging ? (
                  <BatteryCharging size={13} color="var(--accent-emerald)" />
                ) : (
                  <Battery size={13} color={batteryLevel < 20 ? 'var(--accent-rose)' : 'var(--accent-emerald)'} />
                )}
                <span className="mono" style={{ fontSize: '0.68rem', color: batteryLevel < 20 ? 'var(--accent-rose)' : '#fff', fontWeight: 600 }}>
                  {batteryLevel}%
                </span>
              </div>

              {/* Desktop Preview Toggle (Only visible if viewing on desktop) */}
              {!isMobileScreen && (
                <button
                  onClick={() => setViewMode('desktop')}
                  className="btn btn-secondary btn-sm"
                  style={{ padding: '0.25rem 0.45rem', fontSize: '0.68rem' }}
                  title="Switch to Desktop Console"
                >
                  <Monitor size={12} />
                </button>
              )}
            </div>
          </header>

          {/* Native Mobile Screen Body */}
          <main className="mobile-screen-body">
            {/* ----------------------------------------------------
                TAB 1: STREAM (Video Player & Live Playback Telemetry)
                Note: Kept mounted so video playback NEVER stops!
                ---------------------------------------------------- */}
            <div style={{ display: activeMobileTab === 'stream' ? 'flex' : 'none', flexDirection: 'column', gap: '0.85rem' }}>
              {/* Responsive 16:9 Video Player */}
              <div style={{ borderRadius: '14px', overflow: 'hidden', boxShadow: 'var(--shadow-lg)', border: '1px solid var(--border-subtle)' }}>
                <VideoPlayer
                  selectedStreamUrl={selectedStreamUrl}
                  setSelectedStreamUrl={setSelectedStreamUrl}
                  currentLevelIndex={currentLevelIndex}
                  onQualityLevelAssigned={handleQualityLevelAssigned}
                  onTelemetryUpdate={handleTelemetryUpdate}
                  isSimulatorStallActive={isBlackoutActive}
                  isLowBatteryThrottled={isLowBatteryCap}
                  algorithmDecisionReason={algorithmDecisionReason}
                />
              </div>

              {/* Live Playback Telemetry Card */}
              <div className="glass-panel" style={{ padding: '0.85rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: '0.5rem' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem' }}>
                    <span className="pulse-dot online" style={{ width: '6px', height: '6px' }} />
                    <span style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 600, textTransform: 'uppercase' }}>
                      Playback Status:
                    </span>
                  </div>
                  <span className="badge badge-cyan" style={{ fontSize: '0.68rem', padding: '0.15rem 0.45rem' }}>
                    {activeLevelObj.resolution} · {((activeLevelObj.bitrate) / 1000).toFixed(0)} kbps
                  </span>
                </div>

                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.5rem', marginBottom: '0.5rem' }}>
                  <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.45rem 0.6rem', borderRadius: '8px' }}>
                    <div style={{ fontSize: '0.65rem', color: '#64748b' }}>Buffer Reservoir</div>
                    <div className="mono" style={{ fontSize: '1.05rem', fontWeight: 700, color: bufferSeconds < 4.0 ? 'var(--accent-rose)' : 'var(--accent-emerald)' }}>
                      {bufferSeconds.toFixed(1)}s
                    </div>
                  </div>

                  <div style={{ background: 'rgba(0, 0, 0, 0.3)', padding: '0.45rem 0.6rem', borderRadius: '8px' }}>
                    <div style={{ fontSize: '0.65rem', color: '#64748b' }}>ITU-T MOS Score</div>
                    <div className="mono" style={{ fontSize: '1.05rem', fontWeight: 700, color: qoeData.mos >= 4.0 ? 'var(--accent-emerald)' : 'var(--accent-amber)' }}>
                      {qoeData.mos.toFixed(2)} / 5.0
                    </div>
                  </div>
                </div>

                {/* ABR Decision Text */}
                <div style={{ fontSize: '0.68rem', color: '#94a3b8', background: 'rgba(255, 255, 255, 0.03)', padding: '0.4rem 0.6rem', borderRadius: '6px', borderLeft: '2px solid var(--accent-cyan)' }}>
                  <strong style={{ color: '#e2e8f0' }}>ABR Logic: </strong>{algorithmDecisionReason}
                </div>
              </div>

              {/* Quick Mobility Presets */}
              <div className="glass-panel" style={{ padding: '0.85rem' }}>
                <div style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 700, marginBottom: '0.5rem', textTransform: 'uppercase' }}>
                  Quick Mobility Channels:
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '0.4rem' }}>
                  <button
                    onClick={() => handleSelectScenario(MOBILE_SCENARIOS.STABLE_5G)}
                    className={`btn btn-sm ${currentScenario?.id === 'STABLE_5G' ? 'btn-primary' : 'btn-secondary'}`}
                    style={{ fontSize: '0.72rem', padding: '0.5rem 0.3rem', justifyContent: 'center' }}
                  >
                    <Sparkles size={14} />
                    <span>5G mmWave</span>
                  </button>

                  <button
                    onClick={() => handleSelectScenario(MOBILE_SCENARIOS.HIGHWAY_HANDOVER)}
                    className={`btn btn-sm ${currentScenario?.id === 'HIGHWAY_HANDOVER' ? 'btn-primary' : 'btn-secondary'}`}
                    style={{ fontSize: '0.72rem', padding: '0.5rem 0.3rem', justifyContent: 'center' }}
                  >
                    <Car size={14} />
                    <span>Highway 4G</span>
                  </button>

                  <button
                    onClick={() => handleSelectScenario(MOBILE_SCENARIOS.SUBWAY_COMMUTE)}
                    className={`btn btn-sm ${currentScenario?.id === 'SUBWAY_COMMUTE' ? 'btn-primary' : 'btn-secondary'}`}
                    style={{ fontSize: '0.72rem', padding: '0.5rem 0.3rem', justifyContent: 'center' }}
                  >
                    <TrainFront size={14} />
                    <span>Subway Tunnel</span>
                  </button>

                  <button
                    onClick={() => handleSelectScenario(MOBILE_SCENARIOS.BATTERY_CRITICAL)}
                    className={`btn btn-sm ${currentScenario?.id === 'BATTERY_CRITICAL' ? 'btn-purple' : 'btn-secondary'}`}
                    style={{ fontSize: '0.72rem', padding: '0.5rem 0.3rem', justifyContent: 'center' }}
                  >
                    <BatteryLow size={14} />
                    <span>Low Battery</span>
                  </button>
                </div>

                {/* Instant Tunnel Blackout Button */}
                <div style={{ marginTop: '0.5rem' }}>
                  <button
                    onClick={handleTriggerBlackout}
                    disabled={isBlackoutActive}
                    className="btn btn-secondary btn-sm"
                    style={{
                      width: '100%',
                      borderColor: isBlackoutActive ? 'var(--accent-rose)' : 'rgba(255, 77, 109, 0.4)',
                      color: isBlackoutActive ? 'var(--accent-rose)' : '#fca5a5',
                      background: isBlackoutActive ? 'rgba(255, 77, 109, 0.15)' : 'rgba(255, 77, 109, 0.05)',
                      padding: '0.45rem',
                      fontSize: '0.72rem'
                    }}
                  >
                    <ShieldAlert size={14} color="var(--accent-rose)" />
                    <span>{isBlackoutActive ? 'Simulating 4s Blackout (0 kbps)...' : 'Test Sudden Tunnel Blackout (4s Drop)'}</span>
                  </button>
                </div>
              </div>

              {/* Stream Selector Picker */}
              <div className="glass-panel" style={{ padding: '0.85rem' }}>
                <div style={{ fontSize: '0.72rem', color: '#94a3b8', fontWeight: 700, marginBottom: '0.4rem', textTransform: 'uppercase' }}>
                  Select Test Stream:
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.35rem' }}>
                  {SAMPLE_STREAMS.map((s, idx) => (
                    <button
                      key={idx}
                      onClick={() => setSelectedStreamUrl(s.url)}
                      className={`btn btn-sm ${selectedStreamUrl === s.url ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ justifyContent: 'space-between', padding: '0.45rem 0.65rem', fontSize: '0.72rem' }}
                    >
                      <span style={{ fontWeight: 600 }}>{s.name}</span>
                      <span style={{ opacity: 0.8, fontSize: '0.65rem' }}>{s.genre}</span>
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* ----------------------------------------------------
                TAB 2: NETWORK (Live Bandwidth, Latency, Loss, Jitter)
                ---------------------------------------------------- */}
            <div style={{ display: activeMobileTab === 'network' ? 'block' : 'none' }}>
              <LiveNetworkMonitor
                isEmbedded={true}
                currentBandwidthKbps={simulatedBandwidthKbps}
                currentLatencyMs={simulatedLatencyMs}
                currentPacketLossPct={simulatedPacketLossPct}
                currentJitterMs={simulatedJitterMs}
                networkType={networkType}
                currentScenarioName={currentScenario?.name || 'Mobile Wireless Link'}
                isBlackoutActive={isBlackoutActive}
                activeVideoBitrate={activeLevelObj.bitrate}
              />
            </div>

            {/* ----------------------------------------------------
                TAB 3: MOBILITY (Full Channel & Mobility Simulator)
                ---------------------------------------------------- */}
            <div style={{ display: activeMobileTab === 'mobility' ? 'block' : 'none' }}>
              <NetworkSimulator
                currentScenario={currentScenario}
                onSelectScenario={handleSelectScenario}
                simulatedBandwidthKbps={simulatedBandwidthKbps}
                setSimulatedBandwidthKbps={setSimulatedBandwidthKbps}
                simulatedLatencyMs={simulatedLatencyMs}
                setSimulatedLatencyMs={setSimulatedLatencyMs}
                simulatedPacketLossPct={simulatedPacketLossPct}
                setSimulatedPacketLossPct={setSimulatedPacketLossPct}
                simulatedJitterMs={simulatedJitterMs}
                setSimulatedJitterMs={setSimulatedJitterMs}
                batteryLevel={batteryLevel}
                setBatteryLevel={setBatteryLevel}
                isCharging={isCharging}
                setIsCharging={setIsCharging}
                onTriggerBlackoutTunnel={handleTriggerBlackout}
                isBlackoutActive={isBlackoutActive}
              />
            </div>

            {/* ----------------------------------------------------
                TAB 4: TELEMETRY (QoE MOS, Charts & Mobile Power)
                ---------------------------------------------------- */}
            <div style={{ display: activeMobileTab === 'telemetry' ? 'flex' : 'none', flexDirection: 'column', gap: '0.85rem' }}>
              <TelemetryCharts
                telemetryHistory={telemetryHistory}
                currentBuffer={bufferSeconds}
                currentBitrate={activeLevelObj.bitrate}
                currentThroughput={simulatedBandwidthKbps * 1000}
              />

              <QoEDashboard
                qoeData={qoeData}
                totalStallCount={totalStallCount}
                totalStallDuration={totalStallDuration}
                switchCount={switchCount}
                powerStats={powerStats}
                droppedFrames={droppedFrames}
                totalFrames={totalFrames}
                isLowBatteryMode={isLowBatteryCap}
              />
            </div>

            {/* ----------------------------------------------------
                TAB 5: TOOLS & MORE (Benchmark, Thesis, Settings)
                ---------------------------------------------------- */}
            <div style={{ display: activeMobileTab === 'more' ? 'flex' : 'none', flexDirection: 'column', gap: '0.85rem' }}>
              {/* Algorithm Chooser Card */}
              <div className="glass-panel" style={{ padding: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.65rem' }}>
                  <Cpu size={16} color="var(--accent-cyan)" />
                  <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>Choose ABR Algorithm:</span>
                </div>
                <div style={{ display: 'flex', flexDirection: 'column', gap: '0.4rem' }}>
                  {[
                    { id: 'MEDIAFLOW_HYBRID', name: 'MediaFlow Hybrid (Recommended)', desc: 'Consensus min(BBA, EWMA) + dB/dt drain + battery capping' },
                    { id: 'BBA', name: 'Buffer-Based (BBA - Huang et al.)', desc: 'Playout buffer reservoir & cushion scaling' },
                    { id: 'THROUGHPUT_EWMA', name: 'Throughput EWMA Heuristic', desc: 'Exponential moving average of past segment speeds' },
                    { id: 'NAIVE_STATIC', name: 'Naive Static 1080p', desc: 'Fixed resolution baseline control' }
                  ].map((algo) => (
                    <button
                      key={algo.id}
                      onClick={() => setSelectedAlgorithm(algo.id)}
                      className={`btn btn-sm ${selectedAlgorithm === algo.id ? 'btn-primary' : 'btn-secondary'}`}
                      style={{ flexDirection: 'column', alignItems: 'flex-start', padding: '0.55rem 0.75rem', height: 'auto' }}
                    >
                      <span style={{ fontWeight: 700, fontSize: '0.78rem' }}>{algo.name}</span>
                      <span style={{ fontSize: '0.65rem', opacity: 0.8 }}>{algo.desc}</span>
                    </button>
                  ))}
                </div>
              </div>

              {/* Research Benchmark Trigger Card */}
              <div className="glass-panel" style={{ padding: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
                  <GitCompare size={16} color="var(--accent-violet)" />
                  <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>A/B Stress Test Suite</span>
                </div>
                <p style={{ fontSize: '0.72rem', color: '#94a3b8', margin: '0 0 0.65rem 0' }}>
                  Run an automated 60-second comparative stress test between MediaFlow and baseline players and export results to CSV.
                </p>
                <button
                  onClick={() => setIsBenchmarkOpen(true)}
                  className="btn btn-purple btn-sm"
                  style={{ width: '100%', padding: '0.55rem', fontSize: '0.78rem' }}
                >
                  <GitCompare size={14} />
                  <span>Launch A/B Benchmark Modal</span>
                </button>
              </div>

              {/* Thesis Guide Card */}
              <div className="glass-panel" style={{ padding: '1rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '0.4rem', marginBottom: '0.4rem' }}>
                  <BookOpen size={16} color="var(--accent-cyan)" />
                  <span style={{ fontSize: '0.85rem', fontWeight: 700 }}>Capstone Architecture Guide</span>
                </div>
                <p style={{ fontSize: '0.72rem', color: '#94a3b8', margin: '0 0 0.65rem 0' }}>
                  Review mathematical formulations ($dB/dt$, ITU-T P.1203 MOS, energy models) and system architecture diagrams.
                </p>
                <button
                  onClick={() => setIsExplainerOpen(true)}
                  className="btn btn-outline-cyan btn-sm"
                  style={{ width: '100%', padding: '0.55rem', fontSize: '0.78rem' }}
                >
                  <BookOpen size={14} />
                  <span>Open Thesis Reference Guide</span>
                </button>
              </div>
            </div>
          </main>

          {/* Native Mobile Bottom Navigation Bar */}
          <nav className="mobile-bottom-nav">
            <button
              className={`mobile-tab-btn ${activeMobileTab === 'stream' ? 'active' : ''}`}
              onClick={() => setActiveMobileTab('stream')}
            >
              <Film size={18} />
              <span>Stream</span>
            </button>

            <button
              className={`mobile-tab-btn ${activeMobileTab === 'network' ? 'active' : ''}`}
              onClick={() => setActiveMobileTab('network')}
            >
              <Activity size={18} />
              <span>Network</span>
            </button>

            <button
              className={`mobile-tab-btn ${activeMobileTab === 'mobility' ? 'active' : ''}`}
              onClick={() => setActiveMobileTab('mobility')}
            >
              <Radio size={18} />
              <span>Mobility</span>
            </button>

            <button
              className={`mobile-tab-btn ${activeMobileTab === 'telemetry' ? 'active' : ''}`}
              onClick={() => setActiveMobileTab('telemetry')}
            >
              <TrendingUp size={18} />
              <span>Telemetry</span>
            </button>

            <button
              className={`mobile-tab-btn ${activeMobileTab === 'more' ? 'active' : ''}`}
              onClick={() => setActiveMobileTab('more')}
            >
              <Sliders size={18} />
              <span>Tools</span>
            </button>
          </nav>
        </div>
      ) : (
        /* ========================================================
            2. DESKTOP CONSOLE VIEW (For Wide Computer Screens)
            ======================================================== */
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
          {/* Top Half: Video Player + Network Simulator Side-by-Side */}
          <div style={{ display: 'grid', gridTemplateColumns: 'minmax(480px, 1.4fr) 1fr', gap: '1.5rem' }}>
            <VideoPlayer
              selectedStreamUrl={selectedStreamUrl}
              setSelectedStreamUrl={setSelectedStreamUrl}
              currentLevelIndex={currentLevelIndex}
              onQualityLevelAssigned={handleQualityLevelAssigned}
              onTelemetryUpdate={handleTelemetryUpdate}
              isSimulatorStallActive={isBlackoutActive}
              isLowBatteryThrottled={isLowBatteryCap}
              algorithmDecisionReason={algorithmDecisionReason}
            />

            <NetworkSimulator
              currentScenario={currentScenario}
              onSelectScenario={handleSelectScenario}
              simulatedBandwidthKbps={simulatedBandwidthKbps}
              setSimulatedBandwidthKbps={setSimulatedBandwidthKbps}
              simulatedLatencyMs={simulatedLatencyMs}
              setSimulatedLatencyMs={setSimulatedLatencyMs}
              simulatedPacketLossPct={simulatedPacketLossPct}
              setSimulatedPacketLossPct={setSimulatedPacketLossPct}
              simulatedJitterMs={simulatedJitterMs}
              setSimulatedJitterMs={setSimulatedJitterMs}
              batteryLevel={batteryLevel}
              setBatteryLevel={setBatteryLevel}
              isCharging={isCharging}
              setIsCharging={setIsCharging}
              onTriggerBlackoutTunnel={handleTriggerBlackout}
              isBlackoutActive={isBlackoutActive}
            />
          </div>

          {/* Bottom Half: Charts + QoE Analytics */}
          <LiveNetworkMonitor
            isEmbedded={true}
            currentBandwidthKbps={simulatedBandwidthKbps}
            currentLatencyMs={simulatedLatencyMs}
            currentPacketLossPct={simulatedPacketLossPct}
            currentJitterMs={simulatedJitterMs}
            networkType={networkType}
            currentScenarioName={currentScenario?.name || 'Mobile Wireless Link'}
            isBlackoutActive={isBlackoutActive}
            activeVideoBitrate={activeLevelObj.bitrate}
          />

          <TelemetryCharts
            telemetryHistory={telemetryHistory}
            currentBuffer={bufferSeconds}
            currentBitrate={activeLevelObj.bitrate}
            currentThroughput={simulatedBandwidthKbps * 1000}
          />

          <QoEDashboard
            qoeData={qoeData}
            totalStallCount={totalStallCount}
            totalStallDuration={totalStallDuration}
            switchCount={switchCount}
            powerStats={powerStats}
            droppedFrames={droppedFrames}
            totalFrames={totalFrames}
            isLowBatteryMode={isLowBatteryCap}
          />
        </div>
      )}

      {/* Live Network & Wireless Channel Monitor Modal */}
      <LiveNetworkMonitor
        isOpen={isNetworkMonitorOpen}
        onClose={() => setIsNetworkMonitorOpen(false)}
        currentBandwidthKbps={simulatedBandwidthKbps}
        currentLatencyMs={simulatedLatencyMs}
        currentPacketLossPct={simulatedPacketLossPct}
        currentJitterMs={simulatedJitterMs}
        networkType={networkType}
        currentScenarioName={currentScenario?.name || 'Mobile Wireless Link'}
        isBlackoutActive={isBlackoutActive}
        activeVideoBitrate={activeLevelObj.bitrate}
      />

      {/* A/B Benchmark Modal */}
      <BenchmarkModal
        isOpen={isBenchmarkOpen}
        onClose={() => setIsBenchmarkOpen(false)}
      />

      {/* Capstone Theory & Architecture Modal */}
      <ArchitectureExplainerModal
        isOpen={isExplainerOpen}
        onClose={() => setIsExplainerOpen(false)}
      />
    </div>
  );
}
