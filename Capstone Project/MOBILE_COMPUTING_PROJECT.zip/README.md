# MediaFlow: Adaptive Mobile Multimedia Streaming & Performance Optimization

> **Mobile Computing Capstone Project**  
> An experimental research and evaluation platform for Context-Aware Adaptive Bitrate (ABR) streaming over dynamic mobile channels with real-time ITU-T P.1203 QoE formulation and mobile energy modeling.

---

## 📱 Project Overview

Mobile video streaming faces unique challenges that do not exist on fixed broadband connections:
1. **Severe Channel Non-Stationarity**: Wireless signal fading, high mobility velocities (e.g. 100 km/h highway commutes), base-station handovers (4G/5G), and sudden dead-zones (subway tunnels, elevators).
2. **Physical Device Constraints**: Finite battery reserves, battery aging, thermal throttling, and hardware video decoder processing limits.

**MediaFlow** addresses these challenges through a unified, context-aware adaptive streaming engine. It balances network throughput estimations, playback buffer dynamics ($dB/dt$), mobile battery status, and hardware frame drop rates to maximize Quality of Experience (QoE) while saving mobile power.

---

## 🏗️ System Architecture

```
                                  ┌─────────────────────────────┐
                                  │   HLS Master Manifest /      │
                                  │   Multi-Bitrate Stream      │
                                  └──────────────┬──────────────┘
                                                 │
                                                 ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                   MediaFlow Engine                                     │
│                                                                                        │
│  ┌───────────────────────┐   ┌────────────────────────┐   ┌─────────────────────────┐  │
│  │ Mobile Context Engine │   │   Channel Simulator    │   │ Video Playback Pipeline │  │
│  │ • Battery Status/Watt │   │ • 5G / 4G / 3G Presets │   │ • HLS.js Demuxer        │  │
│  │ • Hardware Dropped FPS│   │ • RTT Latency & Jitter │   │ • Buffer Reservoir      │  │
│  │ • Battery Cap Rules   │   │ • 4s Blackout Tunnel   │   │ • HTMLMediaElement      │  │
│  └───────────┬───────────┘   └───────────┬────────────┘   └────────────┬────────────┘  │
│              │                           │                             │               │
│              └─────────────────────────┐ │ ┌───────────────────────────┘               │
│                                        ▼ ▼ ▼                                           │
│                          ┌───────────────────────────────┐                             │
│                          │  Multi-Factor ABR Controller  │                             │
│                          │  • EWMA Throughput Consensus  │                             │
│                          │  • Buffer-Based Scaling (BBA) │                             │
│                          │  • dB/dt Drainage Protection  │                             │
│                          │  • Anti-Oscillation Dwell     │                             │
│                          └───────────────┬───────────────┘                             │
│                                          │ Quality Level (0 - 4)                       │
│                                          ▼                                             │
│                          ┌───────────────────────────────┐                             │
│                          │  Real-Time Telemetry Engine   │                             │
│                          │  • ITU-T P.1203 MOS Score     │                             │
│                          │  • GPU/Radio Power Model (mW) │                             │
│                          │  • High-DPI Canvas Graphs     │                             │
│                          └───────────────────────────────┘                             │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

---

## ⚡ Core Algorithms Implemented

### 1. MediaFlow Hybrid (Core Research Optimizer)
- **Consensus Decision**: Calculates safe bounds from both Buffer-Based Adaptation (BBA) and Throughput EWMA, selecting the safer minimum to prevent buffer exhaustion.
- **Predictive Buffer Drainage ($dB/dt$)**: Detects rapid buffer deflation ($dB/dt < -0.6\text{ s/s}$) and proactively steps down before a stall occurs.
- **Battery-Aware Thermal Capping**:
  - **$\le 15\%$ Battery**: Automatically caps video resolution to 480p to reduce hardware decoder compute load and GPU heat dissipation.
  - **$\le 25\%$ Battery**: Caps resolution to 720p HD.
- **Hardware Decoder Protection**: Monitors `getVideoPlaybackQuality().droppedVideoFrames`. If dropped frame ratio exceeds 5%, quality steps down to relieve CPU/GPU bottlenecks.
- **Anti-Oscillation Hysteresis**: Requires a minimum 5-second dwell time before upward quality switches, eliminating disruptive ping-pong oscillations.

### 2. Buffer-Based Adaptation (BBA - Huang et al.)
- **Reservoir Zone ($< 4.0\text{s}$)**: Emergency floor (240p).
- **Cushion Zone ($4.0\text{s} - 18.0\text{s}$)**: Proportional linear interpolation across the bitrate ladder.
- **Safe Zone ($> 18.0\text{s}$)**: Maximum quality (1080p FHD).

### 3. Throughput EWMA (Traditional Heuristic)
- Smoothed bandwidth estimation with safety factor $\beta = 0.85$:
  $$\hat{T}_t = (1 - \alpha) \cdot \hat{T}_{t-1} + \alpha \cdot T_t$$

### 4. Naive Static Baseline
- Fixed at highest resolution (1080p), serving as an experimental control to measure stalls and battery waste during network degradations.

---

## 📊 Performance Formulations

### Standardized ITU-T P.1203 QoE Formulation
Computes a Mean Opinion Score ($MOS \in [1.0, 5.0]$):
$$QoE = q(R) - \mu \cdot \text{StallPenalty} - \lambda \cdot \text{SwitchPenalty}$$
- $q(R)$: Visual quality logarithmically scaled from bitrate ladder.
- $\mu \cdot \text{StallPenalty}$: Exponential penalty on rebuffering stall ratio.
- $\lambda \cdot \text{SwitchPenalty}$: Instability penalty on frequent switching.

### Mobile Energy Consumption Model
$$P_{\text{total}} = P_{\text{base}} + P_{\text{decoder}}(\text{resolution}) + P_{\text{radio}}(\text{network})$$
- **Base Power**: $400\text{ mW}$ (Display + Audio + OS runtime)
- **Hardware Decoder**: $140\text{ mW}$ (240p) to $950\text{ mW}$ (1080p 60fps)
- **Radio Interface**: $850\text{ mW}$ (5G Active) / $520\text{ mW}$ (4G) / $680\text{ mW}$ (3G Retries) / $900\text{ mW}$ (Stall segment retries)

---

## 🧪 Mobility Simulation Scenarios

1. **5G mmWave Ultra-Fast**: 35 Mbps, 18ms latency, 0% loss (urban cell center).
2. **Highway 4G/5G Handover**: 4.5 Mbps, 85ms latency, 45ms jitter, 2.5% loss (rapid tower transitions).
3. **Subway / Tunnel Transit**: 1.1 Mbps, 240ms latency, 110ms jitter, 8.0% loss (multipath fading).
4. **Crowded Stadium**: 750 kbps, 380ms latency, 12% loss (extreme contention).
5. **Low Battery Saver (< 15%)**: 12 Mbps, forced 12% battery state (triggers power-saver cap).
6. **Sudden Tunnel Blackout**: Injects an instantaneous 4-second drop to 0 kbps.

---

## 🛠️ Project Structure

```
├── src/
│   ├── algorithms/
│   │   └── abrEngine.js               # ABR algorithms, ITU-T QoE, Energy model, Presets
│   ├── components/
│   │   ├── Navbar.jsx                  # Top navigation, algorithm picker, device telemetry
│   │   ├── VideoPlayer.jsx             # HLS.js MSE video player with stall detection
│   │   ├── NetworkSimulator.jsx        # Mobility presets, bandwidth/RTT/jitter/battery sliders
│   │   ├── TelemetryCharts.jsx         # Real-time HTML5 60fps canvas telemetry graphs
│   │   ├── QoEDashboard.jsx            # ITU-T P.1203 MOS score, stall and energy stats
│   │   ├── BenchmarkModal.jsx          # Quantitative A/B stress test suite & CSV exporter
│   │   └── ArchitectureExplainerModal.jsx # Capstone theory, equations & architecture guide
│   ├── App.jsx                         # Main orchestrator, adaptation loop, mobile mockup
│   ├── index.css                       # Complete design system (Dark mode, glassmorphism)
│   └── main.jsx                        # React 19 bootstrap entry
├── public/                             # Public static assets & SVG icons
├── package.json                        # Dependencies (React 19, HLS.js, Lucide, Vite)
└── vite.config.js                      # Vite build configuration
```

---

## 🚀 Getting Started

### Prerequisites
- Node.js (v18.0.0 or higher)
- npm or pnpm

### Installation
```bash
npm install
```

### Run Locally (Development Server)
```bash
npm run dev
```
Open [http://localhost:5173](http://localhost:5173) in your browser.

### Run Linter
```bash
npm run lint
```

### Production Build
```bash
npm run build
```

---

## 📈 Benchmark & Thesis Evaluation Suite

The application includes an **A/B Benchmark Suite** accessible directly from the top navigation bar:
- Runs automated 60-second stress tests comparing **MediaFlow Hybrid** vs **Standard Baseline**.
- Generates comparative tables on stall counts, stall duration, oscillation frequency, energy consumption, and MOS score.
- **Export to CSV**: Allows one-click export of experimental findings for inclusion in academic papers, thesis reports, and presentations.
