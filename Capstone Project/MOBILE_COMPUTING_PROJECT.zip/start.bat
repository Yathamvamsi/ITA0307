@echo off
echo ========================================================
echo   MediaFlow Mobile Computing Capstone Project
echo ========================================================
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Node.js is not detected on this computer.
    echo Please download and install Node.js (LTS version) from:
    echo   https://nodejs.org/
    echo.
    pause
    exit /b
)

if not exist node_modules (
    echo [INFO] First-time setup detected.
    echo [INFO] Installing project dependencies (React, Vite, HLS.js, Lucide)...
    echo.
    call npm install
    if %errorlevel% neq 0 (
        echo.
        echo [ERROR] Failed to install packages. Please verify your internet connection.
        pause
        exit /b
    )
)

echo.
echo ========================================================
echo   Launching MediaFlow Development Server...
echo   Open in browser: http://localhost:5173
echo   (Press Ctrl+C in this window anytime to stop)
echo ========================================================
echo.

call npm run dev
pause
